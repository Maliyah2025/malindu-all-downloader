# Third-party components

This project is distributed under GPL-3.0-or-later; see LICENSE.txt. Keep these notices and provide corresponding source when distributing builds.

- yt-dlp Android wrapper: https://github.com/yausername/youtubedl-android (GPL-3.0).
- yt-dlp: https://github.com/yt-dlp/yt-dlp (Unlicense; components have their own licenses).
- gallery-dl: https://github.com/mikf/gallery-dl (GPL-2.0; inspect bundled release notices for exact terms).
- FFmpeg: https://ffmpeg.org/legal.html (LGPL/GPL depending on enabled components; wrapper's binary build sources: https://github.com/yausername/youtubedl-android/blob/master/BUILD_FFMPEG.md).
- QuickJS: https://bellard.org/quickjs/ (MIT).
- Chaquopy: https://github.com/chaquo/chaquopy (MIT; Python/runtime components retain their licenses).
- CPython: https://docs.python.org/3/license.html (PSF).
- Requests: https://github.com/psf/requests (Apache-2.0).
- Gradle wrapper: https://github.com/gradle/gradle (Apache-2.0).

Dependency artifacts carry additional notices. Source URL and build version are recorded in Gradle files. The Python image dependencies are resolved at build time to accommodate site changes; record `pip` build output for a public release. No service login cookies, passwords or signing keystores are included in this source project.
