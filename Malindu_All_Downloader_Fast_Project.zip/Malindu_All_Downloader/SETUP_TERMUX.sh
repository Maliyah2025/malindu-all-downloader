#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install python ffmpeg nodejs -y
termux-setup-storage
python -m pip install -U 'yt-dlp[default]' gallery-dl requests
printf '\nSetup complete. Run: python Malindu_All_Downloader.py\n'
