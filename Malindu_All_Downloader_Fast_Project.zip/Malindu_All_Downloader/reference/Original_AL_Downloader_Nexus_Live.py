#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A/L Lesson Downloader Ultra - Termux local dashboard.

Uses yt-dlp for videos the user has permission to download.
Dashboard shows the current batch only. Old results clear when the next batch starts.
Dashboard runs on phone; optional --lan enables private same-Wi-Fi PC access.
Paste lesson messages in the browser at any time, even during active downloads.
CLI input also accepts full lesson messages ending in DONE.

Requires: python, yt-dlp, ffmpeg (for merging audio/video).
No remote hosting, accounts or external web-service needed beyond video access.
"""
import collections
import csv
import hmac
import io
import ipaddress
import socket
import html
import json
import mimetypes
import os
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
import unicodedata
import webbrowser
from collections import Counter
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

ROOT = Path.home() / 'storage' / 'downloads' / 'AL_Lessons'
if not ROOT.parent.exists():
    ROOT = Path.home() / 'downloads' / 'AL_Lessons'
STATE_DIR = ROOT / '.downloader'
STATE_FILE = STATE_DIR / 'ultra_state.json'
OLD_QUEUE = STATE_DIR / 'queue.json'
ARCHIVE_FILE = STATE_DIR / 'ultra_archive.txt'
PORT = 8765
DEFAULT_SUBJECT = 'Other'
DEFAULT_LESSON = 'Unsorted'
MAX_QUALITY = 1080
LAN_MODE = "--lan" in sys.argv
MIN_FREE_BYTES = 300 * 1024 * 1024
SUBJECTS = {
    "biology": "Biology", "bio": "Biology", "ජීව විද්‍යාව": "Biology",
    "chemistry": "Chemistry", "chem": "Chemistry", "රසායන විද්‍යාව": "Chemistry",
    "physics": "Physics", "phy": "Physics", "භෞතික විද්‍යාව": "Physics",
    "combined maths": "Combined Maths", "mathematics": "Combined Maths",
    "සංයුක්ත ගණිතය": "Combined Maths",
}
SUBJECT_HEADER = re.compile(
    r"(?i)(?:\ba\s*/\s*l\s*|\ba\.?l\.?\s*|\badvanced\s+level\s*)"
    r"(biology|chemistry|physics|combined\s+maths|mathematics|bio|chem|phy)\b"
)
BARE_SUBJECT_HEADER = re.compile(
    r"(?i)^\s*(biology|chemistry|physics|combined\s+maths|mathematics)\s*(?:[|:–—-]|$)"
)
LESSON_PATTERNS = [
    r"පාරිසරික\s+ජීව\s*විද්‍යාව", r"ප්‍රවේණිය", r"සෛල(?:ීය)?\s+ජීව\s*විද්‍යාව",
    r"ජීවයේ\s+රසායනික\s+පදනම", r"ජෛව\s*විවිධත්වය",
    r"අණුක\s+ජීව\s*විද්‍යාව", r"ක්ෂුද්‍ර\s+ජීව\s*විද්‍යාව",
    r"පරිණාමය", r"ජීවීන්ගේ\s+සංවිධානය", r"ශාක\s+පටක", r"සත්ත්ව\s+පටක",
    r"රසායනික\s+ගණනය", r"වායු", r"ශක්ති\s*විද්‍යාව", r"පරමාණුක\s+ව්‍යුහය",
    r"ව්‍යුහය\s+හා\s+බන්ධන", r"දෝලන\s+හා\s+තරංග",
    r"environmental\s+biology", r"ecology", r"genetics", r"cell\s+biology",
    r"evolution", r"microbiology", r"biochemistry", r"chemical\s+calculations",
    r"thermodynamics", r"organic\s+chemistry", r"inorganic\s+chemistry",
    r"atomic\s+structure", r"oscillations\s+and\s+waves",
]
LESSON_RX = re.compile("|".join(f"(?:{p})" for p in LESSON_PATTERNS), re.I)
DAY_RX = re.compile(r"(?i)\b(?:day|session|part|lecture|class)\s*[-:#.]?\s*0*(\d{1,3})\b")
SINHALA_DAY_RX = re.compile(r"(?:දින|දිනය|කොටස)\s*[-:#.]?\s*0*(\d{1,3})")
UNIT_RX = re.compile(r"(?i)\bunit\s*[-:#.]?\s*0*(\d{1,3})\b")
URL_RX = re.compile(r"https?://[^\s<>\"']+", re.I)


def clean_line(line):
    line = line.replace("\u200b", "").replace("\ufeff", "")
    return re.sub(r"\s+", " ", line.strip(" \t*`_>"))


def safe_name(value, default):
    """Preserve Sinhala while making a safe Android path component."""
    value = clean_line(str(value))
    value = "".join(ch for ch in value if (unicodedata.category(ch) not in ("So", "Sk") and ch not in ("\u200b", "\ufeff")))
    value = re.sub(r"[\\/<>:\"|?*\x00-\x1f]", " ", value)
    value = re.sub(r"\s+", " ", value).strip(" .-_")
    value = value[:85].strip()
    # Android file systems also limit filename COMPONENTS by bytes, not just characters.
    while len(value.encode("utf-8")) > 175:
        value = value[:-1]
    return value.strip(" .-_") or default


def lesson_from_line(line):
    """Find the actual lesson name, ignoring generic Unit/Full Pack/footer lines."""
    line = clean_line(line)
    if URL_RX.search(line) or len(line) > 180:
        return None
    if re.search(r"(?i)\b(?:lesson session|download|react|subscribe|channel|teacher|contact|full lesson pack|lesson store)\b", line):
        # 'Full lesson pack' at end of an explicit topic is allowed below.
        if not LESSON_RX.search(line):
            return None
    # Main subject heading: A/L Biology | <LESSON NAME> (English translation)
    m = SUBJECT_HEADER.search(line) or BARE_SUBJECT_HEADER.search(line)
    if m:
        after = line[m.end():].strip(" |:—–- ")
        after = re.sub(r"(?i)\bunit\s*\d+\s*[:\-]?", "", after).strip()
        after = re.sub(r"(?i)\b(?:full\s*)?lesson\s*pack\b.*$", "", after).strip()
        if after and not re.fullmatch(r"(?i)(?:all\s+lessons?|full\s+syllabus|theory)", after):
            return after
    # Generic lesson headings, with a known lesson name, even without subject.
    k = LESSON_RX.search(line)
    if k:
        # If the line is a simple heading, keep whole heading (including its translated name).
        value = line
        value = re.sub(r"(?i)^.*?\bunit\s*0*\d{1,3}\s*[:|\-]\s*", "", value)
        value = re.sub(r"(?i)\b(?:full\s*)?lesson\s*pack\b.*$", "", value)
        value = re.sub(r"(?i)\b(?:by|teacher|sir)\s*[:\-].*$", "", value)
        return value.strip(" |:—–- ") or k.group()
    # Unit NN: Named Topic, but not 'Full Lesson Pack'.
    u = UNIT_RX.search(line)
    if u:
        after = line[u.end():].strip(" |:—–- ")
        if after and not re.search(r"(?i)\b(?:full|lesson|pack|recordings?)\b", after):
            return after
    return None


def identify_subject(line):
    m = SUBJECT_HEADER.search(line) or BARE_SUBJECT_HEADER.search(line)
    if m:
        return SUBJECTS.get(m.group(1).lower().replace("  ", " "))
    lower = clean_line(line).lower()
    for word, subject in SUBJECTS.items():
        if word in lower and ("විද්‍යාව" in word or "ගණිතය" in word):
            # Sinhala subject-only lines (not arbitrary paragraphs).
            if len(lower) < 38:
                return subject
    return None


def get_youtube_id(raw_url):
    try:
        url = urlparse(raw_url.strip(".,;:!?*])}"))
    except ValueError:
        return None
    host = (url.hostname or "").lower()
    path = url.path.strip("/")
    value = None
    if host in ("youtu.be", "www.youtu.be"):
        value = path.split("/")[0]
    elif host in ("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"):
        if path == "watch":
            value = parse_qs(url.query).get("v", [None])[0]
        elif path.startswith(("shorts/", "live/", "embed/")):
            fields = path.split("/")
            value = fields[1] if len(fields) > 1 else None
    return value if value and re.fullmatch(r"[A-Za-z0-9_-]{11}", value) else None


def parse_messages(message):
    """Segment by lesson/subject headings, and associate each video with its nearest heading.

    Ambiguous items go to Unsorted (rather than silently misclassifying them).
    """
    subject, lesson = DEFAULT_SUBJECT, DEFAULT_LESSON
    pending_day = None
    current_counts = Counter()
    videos = []
    seen = set()
    for raw_line in message.splitlines():
        line = clean_line(raw_line)
        if not line:
            continue
        links = [(m.group(), get_youtube_id(m.group())) for m in URL_RX.finditer(line)]
        if not any(vid for _, vid in links):
            next_subject = identify_subject(line)
            if next_subject:
                new_lesson = lesson_from_line(line)
                # New heading means a new block. Do not inherit earlier lesson.
                if next_subject != subject or new_lesson or SUBJECT_HEADER.search(line) or BARE_SUBJECT_HEADER.search(line):
                    subject, lesson = next_subject, (safe_name(new_lesson, DEFAULT_LESSON) if new_lesson else DEFAULT_LESSON)
                    pending_day = None
            else:
                title = lesson_from_line(line)
                if title:
                    lesson = safe_name(title, DEFAULT_LESSON)
                    pending_day = None
            day = DAY_RX.search(line) or SINHALA_DAY_RX.search(line)
            if day:
                pending_day = int(day.group(1))
            continue
        for raw_url, video_id in links:
            if not video_id or video_id in seen:
                continue
            seen.add(video_id)
            key = (subject, lesson)
            current_counts[key] += 1
            day_match = DAY_RX.search(line) or SINHALA_DAY_RX.search(line)
            if day_match:
                label = f"Day {int(day_match.group(1)):02d}"
            elif pending_day is not None:
                label = f"Day {pending_day:02d}"
            else:
                label = f"Video {current_counts[key]:02d}"
            videos.append({
                "id": video_id,
                "url": f"https://www.youtube.com/watch?v={video_id}",
                "subject": safe_name(subject, DEFAULT_SUBJECT),
                "lesson": safe_name(lesson, DEFAULT_LESSON),
                "label": label,
                "status": "pending",
                "added": datetime.now().isoformat(timespec="seconds"),
            })
            # One label applies to one link unless another is given explicitly.
            pending_day = None
    return videos



def now():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def job_clean(j):
    """Normalize imported legacy queue entries."""
    return {
        'id': j['id'], 'url': j.get('url', 'https://www.youtube.com/watch?v='+j['id']),
        'subject': safe_name(j.get('subject', 'Other'), 'Other'),
        'lesson': safe_name(j.get('lesson', 'Unsorted'), 'Unsorted'),
        'label': safe_name(j.get('label', 'Video'), 'Video'),
        'quality_override': (int(j['quality_override']) if str(j.get('quality_override', '')) in ('360','480','720','1080') else None),
        'status': ('queued' if j.get('status') in ('pending', None) else j.get('status')), 'added': j.get('added', now()),
        'progress': 0, 'speed': '', 'eta': '', 'message': '', 'attempts': 0,
        'filename': '', 'updated': now(),
    }


def existing_video(video_id):
    """Find confirmed completed files in lesson library and legacy folder.
    .part, .ytdl, and other temporary files are intentionally excluded.
    """
    videos = ('.mp4', '.mkv', '.webm', '.mov', '.m4v')
    for root in (ROOT, ROOT.parent / 'AL_Lesson_Videos'):
        if not root.is_dir():
            continue
        try:
            for p in root.rglob('*'):
                if p.is_file() and p.suffix.lower() in videos and ('[' + video_id + ']') in p.name:
                    return str(p)
        except OSError:
            pass
    return ''


class DownloadService:
    def __init__(self):
        self.lock = threading.RLock()
        self.jobs = []
        self.settings = {'quality': 720, 'fragments': 8, 'parallel': 1, 'auto_start': True}
        self.paused = False
        self.active = {}  # video ID -> Popen
        self.events = collections.deque(maxlen=80)
        self.token = secrets.token_urlsafe(22)
        self.session_id = secrets.token_urlsafe(24)
        self.remote_code = secrets.token_hex(4).upper()
        self.login_attempts = {}
        self.running = True
        self._dirty = False
        self._last_save = 0
        self._wake = False
        self._was_busy = False
        self.root_ready = False
        self._load()
        self.thread = threading.Thread(target=self._scheduler, daemon=True)
        self.thread.start()

    def _event(self, message):
        self.events.appendleft({'time': now(), 'text': message})
        self._dirty = True

    def _load(self):
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        try:
            obj = json.loads(STATE_FILE.read_text(encoding='utf-8'))
            self.settings.update(obj.get('settings', {}))
            self.settings['quality'] = min(1080, max(144, int(self.settings['quality'])))
            self.settings['parallel'] = min(3, max(1, int(self.settings['parallel'])))
            self.settings['fragments'] = min(12, max(1, int(self.settings['fragments'])))
            self.paused = bool(obj.get('paused', False))
            self.jobs = [job_clean(x) for x in obj.get('jobs', []) if isinstance(x, dict) and x.get('id')]
            for fresh, old in zip(self.jobs, obj.get('jobs', [])):
                fresh.update({k: old[k] for k in ('progress','filename','attempts','message') if k in old})
        except (OSError, ValueError, TypeError, KeyError):
            self.jobs = []
        for j in self.jobs:
            # A crashed process must never leave a falsely 'downloading' state.
            if j['status'] in ('downloading', 'processing'):
                j['status'] = 'queued'
                j['message'] = 'Resuming after restart'
            elif j['status'] == 'pending':
                j['status'] = 'queued'
            if j['status'] in ('done', 'queued', 'failed'):
                path = existing_video(j['id'])
                if path:
                    j['filename'] = path
                    j['status'] = 'done'
                    j['progress'] = 100
                elif j['status'] == 'done':
                    # A file was removed since last run; allow retry.
                    j['status'] = 'queued'
                    j['message'] = 'Previous download file missing; queued again'
        # Restarting the dashboard should not populate it with old completed videos.
        # Only unfinished queue items are restored. Finished files remain on disk.
        self.jobs = [j for j in self.jobs if j['status'] != 'done']
        self._event('Dashboard ready; only current unfinished transfers are shown.')
        self._save(force=True)

    def _save(self, force=False):
        if not force and (not self._dirty or time.time()-self._last_save < 5):
            return
        obj = {'settings': self.settings, 'paused': self.paused, 'jobs': self.jobs}
        try:
            STATE_DIR.mkdir(parents=True, exist_ok=True)
            temp = STATE_FILE.with_suffix('.tmp')
            temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
            temp.replace(STATE_FILE)
            self._dirty = False
            self._last_save = time.time()
        except OSError as e:
            print('State save warning:', e, flush=True)

    def add_message(self, message, subject_override=None, lesson_override=None, quality_override=None):
        message = re.sub(r'(?im)^\s*DONE\s*$', '', message)
        parsed = parse_messages(message)
        if quality_override not in (None, ''):
            quality_override = int(quality_override)
            if quality_override not in (360, 480, 720, 1080):
                raise ValueError('Choose 360, 480, 720 or 1080 quality')
        else:
            quality_override = None
        if subject_override:
            subject_override = safe_name(subject_override, DEFAULT_SUBJECT)
            if len(str(subject_override)) > 85:
                raise ValueError('Subject name too long')
        if lesson_override:
            lesson_override = safe_name(lesson_override, DEFAULT_LESSON)
            if len(str(lesson_override)) > 85:
                raise ValueError('Lesson name too long')
        for item in parsed:
            if subject_override:
                item['subject'] = subject_override
            if lesson_override:
                item['lesson'] = lesson_override
            item['quality_override'] = quality_override
        groups = collections.Counter((x['subject'], x['lesson']) for x in parsed)
        with self.lock:
            known = {j['id'] for j in self.jobs}
            fresh = []
            preexisting = 0
            for item in parsed:
                if item['id'] in known:
                    continue
                if existing_video(item['id']):
                    preexisting += 1
                    known.add(item['id'])
                    continue
                fresh.append(job_clean(item))
                known.add(item['id'])
            # A new batch starts ONLY when every previous entry is finished,
            # canceled or failed. Adding links during downloads never clears.
            if fresh and self.jobs and not self.active and all(
                j['status'] in ('done', 'failed', 'canceled') for j in self.jobs
            ):
                self.jobs.clear()
                self.events.clear()
                self._event('New batch started — previous dashboard results cleared; files retained')
            added = fresh
            self.jobs.extend(added)
            if added:
                self._event(f"{len(added)} new video(s) added without interrupting downloads")
            self._save(force=True)
        return {
            'found': len(parsed), 'added': len(added), 'duplicates': len(parsed)-len(added),
            'groups': [{'subject': s, 'lesson': l, 'videos': n} for (s,l),n in groups.items()],
        }

    def _set_wakelock(self, enabled):
        if enabled == self._wake:
            return
        cmd = 'termux-wake-lock' if enabled else 'termux-wake-unlock'
        if shutil.which(cmd):
            try:
                subprocess.run([cmd], timeout=5, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, check=False)
            except (OSError, subprocess.TimeoutExpired):
                pass
        self._wake = enabled

    def _notify(self, title, text):
        if shutil.which('termux-notification'):
            try:
                subprocess.Popen(['termux-notification', '--title', title,
                                 '--content', text], stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
            except OSError:
                pass

    def _scheduler(self):
        while self.running:
            with self.lock:
                jobs_to_start = []
                busy = len(self.active)
                # Allow the next queued item to begin while active downloads run.
                if not self.paused and self.settings.get('auto_start', True):
                    for j in self.jobs:
                        if busy + len(jobs_to_start) >= int(self.settings['parallel']):
                            break
                        if j['status'] == 'queued' and j['id'] not in self.active:
                            free = shutil.disk_usage(ROOT).free
                            if free < MIN_FREE_BYTES:
                                if j.get('message') != 'Low storage: free at least 300 MB':
                                    j['message'] = 'Low storage: free at least 300 MB'
                                    self._event('Low storage. Downloads will wait for free space.')
                                break
                            j.update(status='downloading', progress=0, speed='', eta='',
                                     message='Starting download...', updated=now())
                            # reserve the job before spawning worker to avoid races
                            self.active[j['id']] = None
                            jobs_to_start.append(j['id'])
                current_busy = bool(self.active)
                if current_busy:
                    self._was_busy = True
                elif self._was_busy and not any(j['status']=='queued' for j in self.jobs):
                    self._was_busy = False
                    done = sum(x['status']=='done' for x in self.jobs)
                    failed = sum(x['status']=='failed' for x in self.jobs)
                    self._event(f'Queue finished: {done} completed, {failed} failed')
                    self._notify('A/L Lessons - Download Finished',
                                 f'{done} completed, {failed} failed. Open dashboard for details.')
                self._save()
            for jid in jobs_to_start:
                threading.Thread(target=self._download, args=(jid,), daemon=True).start()
            self._set_wakelock(current_busy)
            time.sleep(0.65)
        self._set_wakelock(False)

    @staticmethod
    def _parse_progress(line):
        m = re.search(r'\[download\]\s*(\d+(?:\.\d+)?)\s*%', line)
        if not m:
            return None
        speed = re.search(r'\bat\s+([^\s]+/s)', line)
        eta = re.search(r'\bETA\s+(\S+)', line)
        return {'progress': float(m.group(1)),
                'speed': speed.group(1) if speed else '',
                'eta': eta.group(1) if eta else ''}

    def _download(self, jid):
        with self.lock:
            j = next((x for x in self.jobs if x['id'] == jid), None)
            if j is None or j['status'] != 'downloading':
                self.active.pop(jid, None)
                return
            snap = dict(j)
            quality = int(snap.get('quality_override') or self.settings['quality'])
            fragments = int(self.settings['fragments'])
            j['attempts'] += 1
            self._event('Starting: ' + j['label'] + ' / ' + j['lesson'])
        folder = ROOT / snap['subject'] / snap['lesson']
        folder.mkdir(parents=True, exist_ok=True)
        # Keep the 11-character ID in each completed filename for reliable deduplication.
        outname = safe_name(snap['label'], 'Video') + ' - %(title).100B [%(id)s].%(ext)s'
        # Strict resolution cap, automatically selecting the best lower format.
        formats = f'bv*[height<={quality}]+ba/b[height<={quality}]'
        cmd = [sys.executable, '-m', 'yt_dlp', '--no-playlist', '--continue',
            '--no-overwrites', '--newline', '--no-colors', '--no-mtime',
            '--retries', '5', '--fragment-retries', '5', '--socket-timeout', '30',
            '--concurrent-fragments', str(fragments),
            '--format', formats, '--format-sort', f'res:{quality},vext:mp4,aext:m4a',
            '--merge-output-format', 'mp4', '--remux-video', 'mp4',
            '--paths', str(folder), '--output', outname,
            '--no-simulate', snap['url']]
        # Keep .part files: yt-dlp will resume interrupted downloads.
        result = -1
        proc = None
        err_line = ''
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True,
                                    errors='replace', bufsize=1, start_new_session=True)
            with self.lock:
                if j['status'] != 'downloading':
                    try: os.killpg(proc.pid, signal.SIGTERM)
                    except OSError: proc.terminate()
                else:
                    self.active[jid] = proc
            for line in proc.stdout:
                line = line.strip()
                progress = self._parse_progress(line)
                with self.lock:
                    if j['status'] != 'downloading':
                        continue
                    if progress:
                        j.update(progress=progress['progress'], speed=progress['speed'],
                                 eta=progress['eta'], updated=now())
                        self._dirty = True
                    elif '[Merger]' in line or '[VideoRemuxer]' in line or '[Fixup' in line:
                        j['message'] = 'Merging video and audio...'
                        self._dirty = True
                    elif 'Destination:' in line or 'has already been downloaded' in line:
                        j['message'] = line[:190]
                        self._dirty = True
                    elif 'ERROR:' in line:
                        err_line = line[:220]
            result = proc.wait()
        except (OSError, ValueError) as e:
            err_line = str(e)
        finally:
            with self.lock:
                self.active.pop(jid, None)
                if j['status'] == 'downloading':
                    path = existing_video(jid)
                    if result == 0 and path:
                        j.update(status='done', progress=100, speed='', eta='',
                                 filename=path, message='Completed', updated=now())
                        self._event('Completed: ' + j['label'] + ' / ' + j['lesson'])
                    elif result == 0:
                        j.update(status='failed', speed='', eta='',
                                 message='yt-dlp returned success, but finished video not found')
                        self._event('File check failed: ' + j['label'])
                    else:
                        j.update(status='failed', speed='', eta='',
                                 message=err_line or ('yt-dlp exit code ' + str(result)))
                        self._event('Failed: ' + j['label'])
                self._save(force=True)

    def _stop(self, jid, new_status):
        with self.lock:
            j = next((x for x in self.jobs if x['id']==jid), None)
            if j is None:
                return False
            j['status'] = new_status
            j.update(speed='', eta='', message=('Paused' if new_status=='paused' else 'Canceled'), updated=now())
            proc = self.active.get(jid)
            self._dirty = True
            self._save(force=True)
        if proc and proc.poll() is None:
            try:
                try: os.killpg(proc.pid, signal.SIGTERM)
                except OSError: proc.terminate()
            except OSError:
                pass
        return True

    def action(self, action, jid=None, subject=None, lesson=None):
        if action == 'pause_all':
            with self.lock:
                self.paused = True
                ids = list(self.active)
                self._event('All downloads paused')
                self._save(force=True)
            for id_ in ids:
                self._stop(id_, 'paused')
            return 'Downloads paused'
        if action == 'resume_all':
            with self.lock:
                self.paused = False
                for j in self.jobs:
                    if j['status'] == 'paused':
                        j['status'] = 'queued'
                self._event('Downloads resumed')
                self._save(force=True)
            return 'Downloads resumed'
        if action == 'retry_failed':
            with self.lock:
                count=0
                for j in self.jobs:
                    if j['status']=='failed':
                        j.update(status='queued', progress=0, message='Retry requested')
                        count+=1
                self._save(force=True)
            return f'{count} failed downloads queued again'
        if action == 'clear_done':
            with self.lock:
                before = len(self.jobs)
                self.jobs = [j for j in self.jobs if j['status'] != 'done']
                self._event('Completed queue items removed; files kept')
                self._save(force=True)
            return f'{before-len(self.jobs)} completed entries removed; no files deleted'
        if not jid:
            raise ValueError('Video ID required')
        with self.lock:
            target = next((j for j in self.jobs if j['id']==jid), None)
            if target is None:
                raise ValueError('Link not found in queue')
        if action in ('pause','cancel'):
            return 'Updated' if self._stop(jid, 'paused' if action=='pause' else 'canceled') else 'Not found'
        with self.lock:
            if action == 'edit':
                if target['status'] in ('downloading', 'done'):
                    raise ValueError('Only queued or paused items can be moved to another folder')
                if not subject or not lesson:
                    raise ValueError('Both subject and lesson name are required')
                target['subject'] = safe_name(subject, 'Other')
                target['lesson'] = safe_name(lesson, 'Unsorted')
                target['message'] = 'Folder updated'
            elif action == 'resume':
                if target['status'] != 'done':
                    target.update(status='queued', progress=0, message='Resuming when a slot is free')
            elif action == 'retry':
                if target['status'] == 'downloading':
                    raise ValueError('Pause active video before retrying')
                target.update(status='queued', progress=0, message='Retry queued')
            elif action in ('up','down'):
                if target['status'] == 'downloading':
                    raise ValueError('Cannot move an active download')
                i = self.jobs.index(target)
                delta = -1 if action == 'up' else 1
                if 0 <= i+delta < len(self.jobs):
                    self.jobs[i],self.jobs[i+delta] = self.jobs[i+delta],self.jobs[i]
            elif action == 'remove':
                if target['status'] == 'downloading':
                    raise ValueError('Cancel active download first')
                self.jobs.remove(target)
            else:
                raise ValueError('Unknown action')
            self._save(force=True)
        return 'OK'

    def set_settings(self, data):
        with self.lock:
            if 'quality' in data:
                quality=int(data['quality'])
                if quality not in (360,480,720,1080):
                    raise ValueError('Choose 360, 480, 720 or 1080')
                self.settings['quality'] = quality
            if 'fragments' in data:
                self.settings['fragments'] = max(1, min(12, int(data['fragments'])))
            if 'parallel' in data:
                self.settings['parallel'] = max(1,min(3,int(data['parallel'])))
            if 'auto_start' in data:
                self.settings['auto_start']=bool(data['auto_start'])
            self._event('Download settings saved; new settings apply to next videos')
            self._save(force=True)
        return 'Settings saved'

    def snapshot(self):
        with self.lock:
            jobs=[dict(j) for j in self.jobs]
            active_count=sum(j['status']=='downloading' for j in jobs)
            counts=collections.Counter(j['status'] for j in jobs)
            d_count=counts['done']
            folder = str(ROOT)
            free=shutil.disk_usage(ROOT).free
            active_speeds=[j['speed'] for j in jobs if j['status']=='downloading' and j['speed']]
            return {
                'jobs': jobs, 'settings': dict(self.settings), 'paused': self.paused,
                'counts': {'total':len(jobs), 'done':d_count,'active':active_count,
                           'queued': counts['queued'], 'paused': counts['paused'],
                           'failed': counts['failed'], 'canceled':counts['canceled']},
                'percent': round(100*d_count/max(1,len(jobs))),
                'speeds':active_speeds, 'free_bytes':free,
                'folder':folder,'events':list(self.events)[:30], 'time':now(),
            }

    def shutdown(self):
        with self.lock:
            self.running=False
            ids=list(self.active)
        for jid in ids:
            self._stop(jid,'paused')
        with self.lock:
            self._save(force=True)
        self._set_wakelock(False)


SERVICE = None

DASHBOARD_HTML = '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n<meta name="theme-color" content="#0b1020"><title>A/L Nexus — Download Studio</title>\n<style>\n:root{color-scheme:dark;--bg:#080c17;--side:#0c1120;--panel:#121a2b;--panel2:#172137;--line:#263149;--text:#f1f5ff;--muted:#99a9c4;--subtle:#667993;--primary:#8578ff;--primary2:#6c94ff;--cyan:#54e3d0;--green:#5ed4a3;--amber:#efc37b;--red:#ff8495;--shadow:0 20px 60px #01041033;--outline:#383f5c}\n*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;min-height:100vh;background:var(--bg);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,\'Segoe UI\',sans-serif;font-size:13px;line-height:1.45}body::before{content:"";position:fixed;inset:-30vh -10vw auto 30vw;height:70vh;pointer-events:none;background:radial-gradient(ellipse,#3633713d,transparent 65%);z-index:-1}button,input,textarea,select{font:inherit}button{cursor:pointer}button:disabled{opacity:.45;cursor:default}a{color:var(--cyan)}.ico{width:18px;height:18px;display:inline-block;flex:none;vertical-align:middle;stroke:currentColor;stroke-width:1.85;stroke-linecap:round;stroke-linejoin:round;fill:none}.ico.lg{width:25px;height:25px}.ico.xl{width:30px;height:30px}\n.shell{display:grid;grid-template-columns:244px minmax(0,1fr);min-height:100vh}.sidebar{position:sticky;top:0;height:100vh;border-right:1px solid #20293d;padding:26px 15px;background:linear-gradient(170deg,#0d1425,#090e19 85%);display:flex;flex-direction:column;gap:27px}.logo{display:flex;align-items:center;gap:10px;padding:0 9px}.mark{width:39px;height:39px;border-radius:13px;display:grid;place-items:center;background:linear-gradient(145deg,#9689ff,#5b8eff);box-shadow:0 7px 24px #6956ef4b;font-size:17px;font-weight:900;color:white;letter-spacing:-1px}.brand strong{display:block;font-size:16px;letter-spacing:-.5px}.brand span{display:block;font-size:9px;text-transform:uppercase;letter-spacing:2px;color:#7f8eac}.nav-label{padding:0 15px;color:#687992;text-transform:uppercase;font-size:10px;font-weight:800;letter-spacing:1.6px;margin-bottom:11px}.nav{display:grid;gap:5px}.nav-btn{display:flex;align-items:center;gap:13px;text-align:left;border:1px solid transparent;background:transparent;color:#98a5c1;padding:12px 15px;border-radius:12px;font-size:13px;font-weight:650;width:100%;transition:background .2s,color .2s}.nav-btn.active{background:linear-gradient(95deg,#7779fe23,#7779fe0c);color:#c9cbff;border-color:#737afb26}.nav-btn:hover{background:#ffffff09;color:white}.nav-btn .ico{width:19px;height:19px}.side-foot{margin-top:auto;padding:15px;background:#151d31;border:1px solid #2b354b;border-radius:16px}.side-foot .dot{background:#4fdca0;width:7px;height:7px;border-radius:50%;display:inline-block;margin-right:5px}.side-foot strong{display:block;font-size:12px;margin-bottom:6px}.side-foot p{color:var(--muted);margin:0;font-size:11px}.side-foot .mini-row{display:flex;justify-content:space-between;margin-top:12px;color:#d8e3f8;font-size:11px}.side-foot .mini-row span{color:var(--muted)}\n.workspace{min-width:0}.topbar{height:75px;border-bottom:1px solid #202a3e;display:flex;justify-content:space-between;align-items:center;padding:0 34px;gap:12px;background:#0b111ecf;backdrop-filter:blur(20px);position:sticky;top:0;z-index:6}.crumb{font-size:12px;color:var(--muted);display:flex;gap:9px;align-items:center}.crumb b{color:var(--text);font-weight:650}.top-actions{display:flex;gap:10px;align-items:center}.live{display:flex;align-items:center;gap:7px;padding:8px 12px;border:1px solid #245545;background:#10362b69;color:#82eec1;border-radius:999px;font-size:11px;font-weight:800}.live::before{content:"";width:7px;height:7px;border-radius:50%;background:#5be8ac;box-shadow:0 0 0 4px #4eda9422}.live.off{color:var(--red);border-color:#723743;background:#41202770}.live.off::before{background:var(--red);box-shadow:none}.avatar{width:32px;height:32px;border:1px solid #4b547b;border-radius:11px;background:linear-gradient(140deg,#524d83,#283b66);display:grid;place-items:center;color:#dad7ff;font-size:11px;font-weight:900}.main{max-width:1570px;padding:28px 34px 76px;margin:auto}.page{display:none}.page.active{display:block}.heading{display:flex;justify-content:space-between;align-items:end;gap:12px;flex-wrap:wrap;margin-bottom:24px}.eyebrow{text-transform:uppercase;letter-spacing:1.8px;font-size:10px;font-weight:800;color:#9c9bf7;margin-bottom:8px}.heading h1{font-size:clamp(25px,3.2vw,34px);font-weight:770;letter-spacing:-1.4px;margin:0 0 6px;line-height:1.2}.heading p{color:var(--muted);margin:0;font-size:13px;max-width:690px}.heading .hero-actions{display:flex;gap:8px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;white-space:nowrap;border-radius:10px;padding:10px 13px;border:1px solid var(--outline);color:var(--text);background:#1d2740;text-decoration:none;font-size:12px;font-weight:750;transition:filter .15s,transform .15s}.btn:hover{filter:brightness(1.16);transform:translateY(-1px)}.btn.primary{background:linear-gradient(120deg,#8476ff,#637fe9);border-color:#9990ff;color:white;box-shadow:0 6px 21px #6a67fb30}.btn.secondary{background:#192339}.btn.soft{background:#1f2942;border-color:#2f3c59}.btn.danger{border-color:#623845;color:#ffb5c0;background:#432430}.btn.mini{padding:6px 9px;border-radius:8px;font-size:11px}.btn.icon-only{padding:8px}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:16px}.stat{position:relative;overflow:hidden;padding:19px;border:1px solid var(--line);border-radius:18px;background:linear-gradient(135deg,#172137,#111827);min-height:134px;box-shadow:var(--shadow)}.stat:after{content:"";position:absolute;right:-40px;bottom:-90px;width:135px;height:135px;border-radius:50%;background:#8983ff0c}.stat-top{display:flex;align-items:center;justify-content:space-between;color:#a0b1ca;font-size:12px;gap:6px}.stat .stat-ic{color:#a69aff;width:33px;height:33px;border-radius:10px;background:#7774ff1a;display:grid;place-items:center}.stat:nth-child(2) .stat-ic{color:var(--green);background:#5ed4a318}.stat:nth-child(3) .stat-ic{color:var(--cyan);background:#54e3d019}.stat:nth-child(4) .stat-ic{color:var(--amber);background:#efc37b17}.stat strong{display:block;margin:16px 0 1px;font-size:30px;font-weight:790;letter-spacing:-1.5px}.stat small{color:var(--subtle);font-size:11px}.cards{display:grid;grid-template-columns:1.3fr 1fr;gap:16px;margin-bottom:16px}.card{border-radius:19px;border:1px solid var(--line);background:linear-gradient(142deg,#151f33,#111928 90%);padding:22px;box-shadow:var(--shadow);min-width:0}.card h2{font-size:15px;font-weight:770;letter-spacing:-.25px;margin:0}.card p.desc{color:var(--muted);font-size:12px;margin:5px 0 17px}.row{display:flex;align-items:center;justify-content:space-between;gap:12px}.row.wrap{flex-wrap:wrap}.meta{color:var(--muted);font-size:11px}.large-num{font-size:30px;font-weight:800;letter-spacing:-1px}.progress{height:9px;border-radius:12px;overflow:hidden;background:#293653}.progress i{height:100%;width:0;display:block;border-radius:12px;background:linear-gradient(90deg,#826eff,#5da5ff,#4fe4c3);transition:width .5s}.kpis{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:14px;color:var(--muted);font-size:11px}.kpis b{color:#e3eafd}.mini-chart{display:flex;gap:5px;align-items:end;height:56px;border-bottom:1px solid #354159;padding-bottom:5px;margin-top:14px}.mini-chart i{flex:1;background:linear-gradient(0deg,#625eff45,#83b2ff);border-radius:4px 4px 0 0;height:12px;opacity:.85}.speed-hero{font-size:28px;letter-spacing:-1px;font-weight:800}.speed-hero small{font-size:12px;letter-spacing:0;color:var(--muted);font-weight:500}.control-mini{display:flex;flex-wrap:wrap;gap:8px;margin-top:15px}\n.add-layout{display:grid;grid-template-columns:1fr 280px;gap:14px}.form-label{display:block;font-weight:650;color:#c1cee4;font-size:12px;margin-bottom:7px}.field{background:#0b1424;border:1px solid #344260;color:#f1f6ff;border-radius:11px;padding:12px;width:100%;outline:none;transition:border-color .15s,box-shadow .15s}.field:focus{border-color:#8784ff;box-shadow:0 0 0 3px #8b84ff24}.field::placeholder{color:#63758d}.paste{resize:vertical;min-height:170px;line-height:1.65;font-size:12px}.two{display:grid;grid-template-columns:1fr 1fr;gap:11px}.hint{font-size:11px;color:var(--muted);margin-top:7px}.hint strong{color:#d0d9e9}.msg{min-height:16px;margin-top:10px;font-size:12px;color:var(--green)}.msg.err{color:var(--red)}.switchrow{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}.check{accent-color:#817af9;width:15px;height:15px;vertical-align:middle}.section-heading{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin:27px 0 12px}.section-heading h2{font-size:17px;margin:0;letter-spacing:-.5px}.searchbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.searchbar .field{width:min(220px,48vw);padding:9px 11px}.searchbar select{width:auto;padding:9px 11px}.queue-list{display:grid;gap:9px}.job{background:#131d30;border:1px solid #28354d;border-radius:14px;padding:14px 16px;transition:border-color .2s}.job:hover{border-color:#424c79}.job-top{display:flex;align-items:start;justify-content:space-between;gap:12px}.job-title{font-weight:750;font-size:13px;line-height:1.4;margin:1px 0 4px}.job-meta{font-size:11px;color:var(--muted);word-break:break-word}.chip{font-size:10px;letter-spacing:.25px;font-weight:800;border-radius:7px;padding:5px 8px;background:#313b57;color:#c7d2ee;white-space:nowrap}.chip.done{color:#75edba;background:#134533}.chip.downloading{color:#80c4ff;background:#17476b}.chip.failed{color:#ff9cab;background:#512d3b}.chip.paused{color:#f3cd83;background:#4b3f26}.chip.canceled{color:#bbc5d8;background:#393c4e}.job-bottom{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:12px}.job-actions{display:flex;flex-wrap:wrap;gap:5px}.job-progress{height:4px;background:#2a3851;border-radius:6px;overflow:hidden;margin-top:12px}.job-progress i{height:100%;display:block;background:linear-gradient(90deg,#766cf6,#49d5d5)}.toolbar{display:flex;gap:8px;flex-wrap:wrap}.empty{border:1px dashed #35425e;border-radius:14px;padding:37px 18px;color:var(--muted);text-align:center;background:#0f1828}.empty .ico{width:32px;height:32px;color:#716ed6;margin-bottom:9px}.empty b{display:block;color:#dfe7f5;margin-bottom:4px}.library-list{display:grid;gap:12px}.folder{border:1px solid #2b3551;border-radius:14px;overflow:hidden;background:#111c30}.folder-head{padding:15px 18px;background:#1d2940;font-weight:730;display:flex;justify-content:space-between;gap:8px;align-items:center}.video{padding:12px 17px;display:flex;justify-content:space-between;gap:12px;align-items:center;border-top:1px solid #26354c}.video a{text-decoration:none;color:#dbe9ff;font-size:12px;word-break:break-word}.video small{font-size:11px;color:var(--muted);white-space:nowrap}.log-list{max-height:460px;overflow-y:auto}.log-item{display:flex;gap:14px;padding:12px 2px;border-bottom:1px solid #2b344d;color:#d2ddef;font-size:12px}.log-item time{white-space:nowrap;color:var(--subtle);font-size:11px}.setting-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}.divider{height:1px;background:#29364b;margin:19px 0}.guide{background:linear-gradient(145deg,#211d3f,#15243a);border:1px solid #58519a65;padding:18px;border-radius:16px}.guide h3{margin:0 0 7px;font-size:13px}.guide p{color:#b6c4e2;margin:0;font-size:12px}.small-note{font-size:11px;color:var(--muted)}.pill{display:inline-flex;gap:5px;align-items:center;border:1px solid #414866;border-radius:8px;padding:5px 8px;font-size:10px;color:#b0bed9;background:#222c40}.kbd{font:700 11px/1.3 ui-monospace,monospace;color:#adadff;background:#292545;border-radius:5px;padding:3px 5px}.toast{position:fixed;right:20px;bottom:20px;max-width:min(420px,calc(100% - 40px));background:#25334d;border:1px solid #6a73a0;box-shadow:0 25px 90px #0009;color:#fff;border-radius:13px;padding:12px 16px;z-index:20;display:none}.toast.open{display:block}.foot{color:#687891;font-size:11px;margin-top:32px;text-align:center}.mobile-nav{display:none}body[data-theme=\'light\']{color-scheme:light;--bg:#edf1fa;--side:#e8ecf5;--panel:#fff;--panel2:#f9faff;--line:#d6ddea;--text:#17233b;--muted:#56647d;--subtle:#60718d;--outline:#c5c9dc;--shadow:0 12px 33px #3f58711a}body[data-theme=\'light\'] .sidebar{background:#f6f7ff}body[data-theme=\'light\'] .topbar{background:#f9faffde}body[data-theme=\'light\'] .card,body[data-theme=\'light\'] .stat,body[data-theme=\'light\'] .job,body[data-theme=\'light\'] .folder{background:#fff}body[data-theme=\'light\'] .field{background:#fff;color:#21314d}body[data-theme=\'light\'] .heading h1{color:#17233b}body[data-theme=\'light\'] .btn{color:#192840;background:#e9ecfa}body[data-theme=\'light\'] .btn.primary{color:#fff}body[data-theme=\'light\'] .nav-btn{color:#66718b}body[data-theme=\'light\'] .nav-btn.active{color:#5752bb}body[data-theme=\'light\'] .side-foot{background:#edf1fa}body[data-theme=\'light\'] .folder-head{background:#f0f3fa}body[data-theme=\'light\'] .video a{color:#273956}\n@media(max-width:1180px){.shell{grid-template-columns:195px minmax(0,1fr)}.main{padding:25px 24px}.topbar{padding:0 24px}.stats{gap:10px}.stat{padding:15px}.add-layout{grid-template-columns:1fr 240px}}\n@media(max-width:960px){.shell{grid-template-columns:1fr}.sidebar{display:none}.main{padding:22px 17px 105px}.topbar{padding:0 17px;height:62px}.mobile-nav{position:fixed;display:flex;bottom:0;left:0;right:0;justify-content:space-around;gap:3px;background:#11182af7;border-top:1px solid #2b354d;padding:9px 6px calc(9px + env(safe-area-inset-bottom));z-index:12;backdrop-filter:blur(20px)}.mobile-nav button{border:0;background:transparent;color:#8493ae;display:grid;place-items:center;gap:5px;min-width:56px;font-size:10px;padding:5px}.mobile-nav button.active{color:#acaaff}.mobile-nav .ico{width:20px;height:20px}.cards{grid-template-columns:1fr 1fr}.add-layout{grid-template-columns:1fr 1fr}}\n@media(max-width:690px){.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.cards,.add-layout{grid-template-columns:1fr}.stat{min-height:118px}.stat strong{font-size:26px;margin-top:12px}.card{padding:17px}.heading{margin-bottom:20px}.heading h1{font-size:28px}.top-actions .avatar{display:none}.setting-grid{grid-template-columns:1fr}.two{grid-template-columns:1fr}.heading .hero-actions{width:100%}.heading .hero-actions .btn{flex:1}.crumb{max-width:54vw;overflow:hidden;white-space:nowrap}}\n@media(prefers-reduced-motion:reduce){*,*::before,*::after{transition:none!important;animation:none!important}}\n</style>\n</head>\n<body>\n<svg aria-hidden="true" width="0" height="0" style="position:absolute"><defs>\n<symbol id="i-grid" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></symbol>\n<symbol id="i-add" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>\n<symbol id="i-list" viewBox="0 0 24 24"><path d="M9 6h12M9 12h12M9 18h12M3.5 6h.01M3.5 12h.01M3.5 18h.01"/></symbol>\n<symbol id="i-folder" viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></symbol>\n<symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></symbol>\n<symbol id="i-settings" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M9.5 3h5l.6 2.2 2 .8 2-.9 2.5 4.3-1.5 1.7v2l1.5 1.7-2.5 4.3-2-.9-2 .8-.6 2.2h-5l-.6-2.2-2-.8-2 .9-2.5-4.3L4.5 13v-2L3 9.3 5.5 5l2 .9 2-.8z"/></symbol>\n<symbol id="i-down" viewBox="0 0 24 24"><path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4"/></symbol>\n<symbol id="i-check" viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></symbol>\n<symbol id="i-play" viewBox="0 0 24 24"><path d="m8 5 11 7-11 7z"/></symbol>\n<symbol id="i-pause" viewBox="0 0 24 24"><path d="M8 5v14M16 5v14"/></symbol>\n<symbol id="i-refresh" viewBox="0 0 24 24"><path d="M20 7v5h-5M4 17v-5h5M5.2 8A8 8 0 0 1 19 9l1 3M4 12l1 3a8 8 0 0 0 13.7 1"/></symbol>\n<symbol id="i-wifi" viewBox="0 0 24 24"><path d="M2 9a15 15 0 0 1 20 0M5 12a11 11 0 0 1 14 0M8.5 16a6 6 0 0 1 7 0M12 20h.01"/></symbol>\n<symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/></symbol>\n<symbol id="i-arrow" viewBox="0 0 24 24"><path d="M5 12h14m-6-6 6 6-6 6"/></symbol>\n<symbol id="i-shield" viewBox="0 0 24 24"><path d="m12 2 9 4v6c0 5-3.5 8-9 10-5.5-2-9-5-9-10V6z"/><path d="m9 12 2 2 4-4"/></symbol>\n<symbol id="i-video" viewBox="0 0 24 24"><rect x="2" y="5" width="15" height="14" rx="2"/><path d="m17 10 5-3v10l-5-3"/></symbol>\n<symbol id="i-edit" viewBox="0 0 24 24"><path d="M12 5H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7M10 14l10-10-2-2L8 12l-1 4z"/></symbol>\n<symbol id="i-bolt" viewBox="0 0 24 24"><path d="m13 2-9 11h7l-1 9 10-12h-7z"/></symbol>\n</defs></svg>\n<div class="shell">\n<aside class="sidebar"><div class="logo"><div class="mark">AL</div><div class="brand"><strong>NEXUS <span style="color:#aaa0ff">PRO</span></strong><span>Lesson Download Studio</span></div></div>\n<div><div class="nav-label">Workspace</div><nav class="nav" id="desktopNav">\n<button class="nav-btn active" data-tab="overview"><svg class="ico"><use href="#i-grid"/></svg> Overview</button>\n<button class="nav-btn" data-tab="add"><svg class="ico"><use href="#i-add"/></svg> Add lessons</button>\n<button class="nav-btn" data-tab="queue"><svg class="ico"><use href="#i-list"/></svg> Download queue</button>\n<button class="nav-btn" data-tab="activity"><svg class="ico"><use href="#i-clock"/></svg> Activity & reports</button>\n<button class="nav-btn" data-tab="settings"><svg class="ico"><use href="#i-settings"/></svg> Settings & PC</button>\n</nav></div>\n<div class="side-foot"><strong><span class="dot"></span>Private local workspace</strong><p>No hosting fees. Your video files stay on the phone.</p><div class="mini-row"><span>Service status</span><b id="sideStatus">Connecting</b></div><div class="mini-row"><span>Available storage</span><b id="sideFree">—</b></div></div></aside>\n<div class="workspace"><div class="topbar"><div class="crumb"><svg class="ico"><use href="#i-grid"/></svg> Workspace <span style="color:#566885">/</span> <b id="pageCrumb">Overview</b></div><div class="top-actions"><span id="live" class="live">CONNECTING</span><div class="avatar">AL</div></div></div>\n<main class="main">\n<section class="page active" id="page-overview"><div class="heading"><div><div class="eyebrow">Command center · real-time</div><h1>Good to see you again <span style="color:#9b97ff">✦</span></h1><p>Watch current transfers, manage the queue and start another lesson batch.</p></div><div class="hero-actions"><button class="btn secondary" data-global="pause_all"><svg class="ico"><use href="#i-pause"/></svg> Pause all</button><button class="btn primary" data-global="resume_all"><svg class="ico"><use href="#i-play"/></svg> Resume</button></div></div>\n<div class="stats"><div class="stat"><div class="stat-top"><span>Total videos</span><span class="stat-ic"><svg class="ico"><use href="#i-video"/></svg></span></div><strong id="sTotal">0</strong><small>In this batch</small></div><div class="stat"><div class="stat-top"><span>Completed</span><span class="stat-ic"><svg class="ico"><use href="#i-check"/></svg></span></div><strong id="sDone">0</strong><small>This batch</small></div><div class="stat"><div class="stat-top"><span>Downloading</span><span class="stat-ic"><svg class="ico"><use href="#i-down"/></svg></span></div><strong id="sActive">0</strong><small>Currently transferring</small></div><div class="stat"><div class="stat-top"><span>Waiting in queue</span><span class="stat-ic"><svg class="ico"><use href="#i-clock"/></svg></span></div><strong id="sQueued">0</strong><small id="sFailed">0 failed</small></div></div>\n<div class="cards"><div class="card"><div class="row"><div><h2>Overall download progress</h2><p class="desc">Live progress for this batch only. Previous results reset when the next batch starts.</p></div><span class="large-num" id="overallPercent">0%</span></div><div class="progress"><i id="overallProgress"></i></div><div class="kpis"><span><b id="progressSummary">0 / 0</b> finished</span><span><b id="overallCount">0</b> in progress or waiting</span><span><b id="progressFailed">0</b> failed</span></div><div class="divider"></div><div class="row"><span class="meta">Current batch</span><span class="pill">AUTO SYNC · 2s</span></div></div>\n<div class="card"><div class="row"><div><h2>Connection & performance</h2><p class="desc">Live transfer and download controls.</p></div><span style="color:var(--cyan)"><svg class="ico lg"><use href="#i-bolt"/></svg></span></div><div class="speed-hero" id="speedText">Idle <small>– no active transfer</small></div><div class="kpis"><span>Free storage: <b id="diskFree">—</b></span><span>Quality: <b id="qualityView">720p</b></span></div><div class="divider"></div><div class="control-mini"><button class="btn primary" data-goto="add"><svg class="ico"><use href="#i-add"/></svg> Add links</button><button class="btn soft" data-goto="queue">Manage queue <svg class="ico"><use href="#i-arrow"/></svg></button></div></div></div>\n<div class="section-heading"><h2>Active downloads</h2><button class="btn mini" data-goto="queue">View full queue <svg class="ico"><use href="#i-arrow"/></svg></button></div><div id="overviewJobs" class="queue-list"></div>\n</section>\n<section class="page" id="page-add"><div class="heading"><div><div class="eyebrow">Simple as copy & paste</div><h1>Add a lesson batch</h1><p>Paste full WhatsApp or Telegram messages. Add links while other videos download — nothing stops.</p></div></div>\n<div class="add-layout"><div class="card"><div class="row wrap"><h2>Paste links or lesson messages</h2><span class="pill">YouTube URL detector</span></div><p class="desc">Paste several lessons together. Type DONE at the end if you like; it is optional here.</p><textarea id="paste" class="field paste" placeholder="🌍 A/L BIOLOGY | පාරිසරික ජීව විද්\u200dයාව&#10;Day 01&#10;https://youtu.be/...&#10;Day 02&#10;https://youtu.be/...&#10;&#10;A/L CHEMISTRY | රසායනික ගණනය&#10;... "></textarea><div class="row wrap" style="margin-top:13px"><span class="hint">Messages may contain non-video links; only supported YouTube videos are added.</span><button class="btn primary" id="addBtn"><svg class="ico"><use href="#i-add"/></svg> Add to queue</button></div><div id="addMsg" class="msg" aria-live="polite"></div></div>\n<div style="display:grid;gap:14px;align-content:start"><div class="card"><h2>Smart organization</h2><p class="desc">Leave blank for auto detection, or set your own folder.</p><label class="form-label" for="subject">Subject (optional)</label><select class="field" id="subject"><option value="">Auto detect subject</option><option>Biology</option><option>Chemistry</option><option>Physics</option><option>Combined Maths</option><option>Other</option></select><div style="height:13px"></div><label class="form-label" for="lesson">Lesson folder (optional)</label><input class="field" id="lesson" placeholder="e.g. පාරිසරික ජීව විද්\u200dයාව" maxlength="85"><div class="hint">Manual lesson name applies to the full pasted batch. Leave it empty if you pasted several different lesson messages.</div><div class="divider"></div><label class="form-label" for="batchQuality">Quality for this batch</label><select class="field" id="batchQuality"><option value="">Use global default (720p)</option><option value="1080">1080p · best ≤1080</option><option value="720">720p · recommended</option><option value="480">480p · data saver</option><option value="360">360p · low data</option></select><p class="hint">If selected quality is unavailable, choose the best supported lower resolution automatically.</p></div><div class="guide"><h3>✦ Zero-click sorting</h3><p>Your links are grouped into <b>Subject → Lesson → Day</b> folders. Duplicate videos are skipped and unfinished downloads can resume after restarting.</p></div></div></div>\n</section>\n<section class="page" id="page-queue"><div class="heading"><div><div class="eyebrow">Manage every transfer</div><h1>Download queue</h1><p>Search, reorder, pause, resume, retry, edit folders and monitor individual videos.</p></div><div class="hero-actions"><button class="btn secondary" data-global="retry_failed"><svg class="ico"><use href="#i-refresh"/></svg> Retry failed</button></div></div>\n<div class="section-heading"><h2>All downloads <span class="pill" id="queueCount">0 videos</span></h2><div class="searchbar"><input class="field" id="search" placeholder="Search lesson or day"><select class="field" id="filter"><option value="all">All statuses</option><option value="downloading">Downloading</option><option value="queued">Queued</option><option value="done">Completed</option><option value="paused">Paused</option><option value="failed">Failed</option><option value="canceled">Canceled</option></select></div></div><div class="queue-list" id="jobs"></div><p class="small-note">Results stay visible until a new batch starts. Auto clear only resets dashboard entries — no video files are deleted.</p>\n</section>\n<section class="page" id="page-activity"><div class="heading"><div><div class="eyebrow">Live session details</div><h1>Current batch activity</h1><p>Only the current batch is tracked here. Older results clear when the next batch starts.</p></div><div class="hero-actions"><a class="btn secondary" href="/report.csv" download>↓ CSV export</a><a class="btn secondary" href="/report.txt" download>↓ Text report</a></div></div><div class="cards"><div class="card"><h2>Current batch timeline</h2><p class="desc">Newest events first</p><div id="eventList" class="log-list"></div></div><div class="card"><h2>Lesson analytics</h2><p class="desc">Live summary grouped by subject</p><div id="subjectStats"></div></div></div></section>\n<section class="page" id="page-settings"><div class="heading"><div><div class="eyebrow">Make it yours</div><h1>Preferences & PC access</h1><p>Smart defaults mean you only need to paste a message and press Add.</p></div></div>\n<div class="card"><h2>Download preferences</h2><p class="desc">These preferences apply to new videos. A batch quality override takes priority.</p><div class="setting-grid"><div><label class="form-label" for="quality">Default maximum quality</label><select class="field" id="quality"><option value="1080">1080p · Full HD</option><option value="720">720p · recommended</option><option value="480">480p · lower data</option><option value="360">360p · lowest data</option></select></div><div><label class="form-label" for="parallel">Simultaneous videos</label><select class="field" id="parallel"><option value="1">1 · stable</option><option value="2">2 · balanced</option><option value="3">3 · fast connection</option></select></div><div><label class="form-label" for="fragments">Concurrent fragments</label><select class="field" id="fragments"><option value="1">1</option><option value="4">4</option><option value="8">8 · recommended</option><option value="12">12</option></select></div></div><div class="row wrap" style="margin-top:18px"><label class="small-note"><input class="check" type="checkbox" id="auto" checked> Start new downloads automatically</label><button id="saveSettings" class="btn primary">Save preferences</button></div><p id="settingsMsg" class="msg" aria-live="polite"></p><div class="divider"></div><div class="row wrap"><span>Interface appearance</span><select class="field" style="max-width:180px" id="theme"><option value="dark">Midnight Dark</option><option value="light">Cloud Light</option></select></div></div>\n<div class="cards" style="margin-top:16px"><div class="card"><h2><svg class="ico"><use href="#i-wifi"/></svg> Free PC dashboard</h2><p class="desc">No hosting required. Works on the same Wi-Fi network.</p><div class="guide"><h3>How to connect</h3><p>Start Termux with <span class="kbd">python AL_Downloader_Nexus_Live.py --lan</span>. The phone shows its local IP and a private access code. On your PC open <span class="kbd">http://PHONE_IP:8765</span> and enter that code.</p></div><p class="hint">Remote access is disabled unless you start with <strong>--lan</strong>. Avoid public Wi-Fi, VPN tunneling or router port forwarding. Both devices must share the same local network; phone must keep Termux running.</p></div><div class="card"><h2>Safety & storage</h2><p class="desc">Built-in safeguards protect your videos.</p><div style="display:grid;gap:12px"><div class="row"><span class="meta">Download folder</span><b class="small-note" id="rootPath">—</b></div><div class="row"><span class="meta">Free space</span><b id="settingsFree">—</b></div><div class="row"><span class="meta">Storage guard</span><span class="pill">300 MB reserve</span></div></div><div class="divider"></div><p class="small-note">Current downloads keep their started resolution. New resolution applies only to future downloads. Wi-Fi speed is not guaranteed by fragment acceleration.</p></div></div>\n</section>\n<p class="foot">NEXUS PRO · 100% LOCAL · BUILT FOR A/L LEARNING · Download only content you\'re allowed to save</p>\n</main></div></div>\n<nav class="mobile-nav" id="mobileNav"><button class="active" data-tab="overview"><svg class="ico"><use href="#i-grid"/></svg> Home</button><button data-tab="add"><svg class="ico"><use href="#i-add"/></svg> Add</button><button data-tab="queue"><svg class="ico"><use href="#i-list"/></svg> Queue</button><button data-tab="settings"><svg class="ico"><use href="#i-settings"/></svg> Settings</button></nav>\n<div class="toast" id="toast" role="status"></div>\n<script>\n\'use strict\';\nconst TOKEN=\'__INSERT_TOKEN__\';\nconst $=id=>document.getElementById(id);\nconst esc=s=>String(s==null?\'\':s).replace(/[&<>"\']/g,c=>({\'&\':\'&amp;\',\'<\':\'&lt;\',\'>\':\'&gt;\',\'"\':\'&quot;\',"\'":\'&#39;\'}[c]));\nconst ico=name=>`<svg class="ico"><use href="#i-${name}"/></svg>`;\nconst fmt=n=>{if(!Number.isFinite(+n))return \'—\';let v=+n;const units=[\'B\',\'KB\',\'MB\',\'GB\',\'TB\'];let i=0;while(v>=1024&&i<4){v/=1024;i++}return `${v.toFixed(i?1:0)} ${units[i]}`};\nlet data=null,settingsReady=false,curTab=\'overview\',lastEventCount=0;\nconst nameMap={overview:\'Overview\',add:\'Add lessons\',queue:\'Download queue\',activity:\'Activity & reports\',settings:\'Settings & PC\'};\nfunction showTab(id){if(!nameMap[id])return;curTab=id;document.querySelectorAll(\'.page\').forEach(x=>x.classList.toggle(\'active\',x.id===\'page-\'+id));document.querySelectorAll(\'[data-tab]\').forEach(x=>x.classList.toggle(\'active\',x.dataset.tab===id));$(\'pageCrumb\').textContent=nameMap[id];window.scrollTo({top:0,behavior:\'instant\'});}\ndocument.querySelectorAll(\'[data-tab]\').forEach(x=>x.addEventListener(\'click\',()=>showTab(x.dataset.tab)));\ndocument.querySelectorAll(\'[data-goto]\').forEach(x=>x.addEventListener(\'click\',()=>showTab(x.dataset.goto)));\nfunction notice(msg,error=false){const el=$(\'toast\');el.textContent=msg;el.style.borderColor=error?\'#844353\':\'#5f66a0\';el.classList.add(\'open\');clearTimeout(notice.timer);notice.timer=setTimeout(()=>el.classList.remove(\'open\'),4500)}\nfunction statusMsg(id,msg,bad=false){$(id).textContent=msg;$(id).classList.toggle(\'err\',bad)}\nasync function req(path,body){const r=await fetch(path,{method:\'POST\',credentials:\'same-origin\',headers:{\'Content-Type\':\'application/json\',\'X-App-Token\':TOKEN},body:JSON.stringify(body)});const txt=await r.json();if(!r.ok)throw Error(txt.error||r.statusText);return txt}\nasync function globalAction(action){try{const x=await req(\'/api/action\',{action});notice(x.message||\'Done\');await refresh()}catch(e){notice(e.message,true)}}\ndocument.querySelectorAll(\'[data-global]\').forEach(x=>x.addEventListener(\'click\',()=>globalAction(x.dataset.global)));\n$(\'addBtn\').addEventListener(\'click\',async()=>{const text=$(\'paste\').value.trim();if(!text){statusMsg(\'addMsg\',\'Paste lesson messages first.\',true);return}const btn=$(\'addBtn\');btn.disabled=true;try{const x=await req(\'/api/add\',{text,subject:$(\'subject\').value,lesson:$(\'lesson\').value,quality:$(\'batchQuality\').value||null});statusMsg(\'addMsg\',`Added ${x.added} video(s), skipped ${x.duplicates} duplicate(s). ${x.groups.map(g=>g.lesson+\' (\'+g.videos+\')\').join(\' · \')}`);notice(x.added+\' videos added to queue\');$(\'paste\').value=\'\';await refresh()}catch(e){statusMsg(\'addMsg\',e.message,true)}finally{btn.disabled=false}});\n$(\'saveSettings\').addEventListener(\'click\',async()=>{try{const x=await req(\'/api/settings\',{quality:+$(\'quality\').value,parallel:+$(\'parallel\').value,fragments:+$(\'fragments\').value,auto_start:$(\'auto\').checked});statusMsg(\'settingsMsg\',x.message);notice(\'Preferences saved\');await refresh()}catch(e){statusMsg(\'settingsMsg\',e.message,true)}});\n$(\'theme\').addEventListener(\'change\',e=>{document.body.dataset.theme=e.target.value;try{localStorage.setItem(\'nexus_theme\',e.target.value)}catch(err){}});\ntry{const t=localStorage.getItem(\'nexus_theme\');if(t===\'light\'){document.body.dataset.theme=\'light\';$(\'theme\').value=\'light\'}}catch(err){}\nconst keyWords={done:\'Completed\',downloading:\'Downloading\',queued:\'Queued\',paused:\'Paused\',failed:\'Failed\',canceled:\'Canceled\'};\nfunction renderItem(j,compact=false){const status=esc(j.status), p=+j.progress||0,meta=`${esc(j.subject)} / ${esc(j.lesson)} · ${esc(j.label)} · ${esc(j.quality_override?j.quality_override+\'p\':\'Default quality\')}`;\n const actions=compact?\'\':`<div class="job-actions">${j.status===\'downloading\'?`<button class="btn mini" data-action="pause" data-id="${esc(j.id)}">${ico(\'pause\')} Pause</button>`:\'\'}${[\'queued\',\'paused\',\'failed\',\'canceled\'].includes(j.status)?`<button class="btn mini" data-action="resume" data-id="${esc(j.id)}">${ico(\'play\')} ${j.status===\'failed\'?\'Retry\':\'Resume\'}</button>`:\'\'}${[\'queued\',\'paused\',\'failed\',\'canceled\'].includes(j.status)?`<button class="btn mini" data-action="edit" data-id="${esc(j.id)}">${ico(\'edit\')} Folder</button>`:\'\'}${j.status===\'queued\'?`<button class="btn mini" data-action="up" data-id="${esc(j.id)}">↑ Priority</button>`:\'\'}${j.status!==\'done\'?`<button class="btn mini" data-action="cancel" data-id="${esc(j.id)}">Cancel</button>`:\'\'}${j.status!==\'downloading\'?`<button class="btn mini" data-action="remove" data-id="${esc(j.id)}">Remove row</button>`:\'\'}</div>`;\nreturn `<div class="job"><div class="job-top"><div style="min-width:0"><div class="job-title">${esc(j.label)} <span style="font-weight:450;color:var(--muted)">·</span> ${esc(j.lesson)}</div><div class="job-meta">${meta}</div></div><span class="chip ${status}">${keyWords[j.status]||status}</span></div>${j.status===\'downloading\'?`<div class="job-progress"><i style="width:${Math.max(0,Math.min(100,p))}%"></i></div>`:\'\'}<div class="job-bottom"><span class="meta">${j.status===\'downloading\'?`${p.toFixed(1)}% · ${esc(j.speed||\'Starting...\')} · ETA ${esc(j.eta||\'—\')}`:esc(j.message||j.url||\'\')}</span>${actions}</div></div>`}\nfunction showEmpty(target,headline,sub){target.innerHTML=`<div class="empty">${ico(\'folder\')}<b>${esc(headline)}</b>${esc(sub)}</div>`}\nfunction renderJobs(){if(!data)return;const all=data.jobs||[];const needle=$(\'search\').value.trim().toLowerCase(),filter=$(\'filter\').value;let arr=all.filter(j=>(filter===\'all\'||j.status===filter)&&(`${j.subject} ${j.lesson} ${j.label} ${j.id}`.toLowerCase().includes(needle)));$(\'queueCount\').textContent=arr.length+\' videos\';const jobs=$(\'jobs\');if(arr.length)jobs.innerHTML=arr.map(j=>renderItem(j)).join(\'\');else showEmpty(jobs,\'Nothing in this view\',\'Try changing search or paste your first lesson message.\');const active=all.filter(j=>j.status===\'downloading\').slice(0,4);if(active.length)$(\'overviewJobs\').innerHTML=active.map(j=>renderItem(j,true)).join(\'\');else showEmpty($(\'overviewJobs\'),\'Nothing downloading right now\',\'Your queued lessons will show here when downloads start.\')}\n$(\'search\').addEventListener(\'input\',renderJobs);$(\'filter\').addEventListener(\'change\',renderJobs);\n$(\'jobs\').addEventListener(\'click\',async e=>{const button=e.target.closest(\'[data-action]\');if(!button)return;const action=button.dataset.action,id=button.dataset.id;let payload={action,id};if(action===\'edit\'){const j=(data.jobs||[]).find(j=>j.id===id);if(!j)return;let lesson=prompt(\'Lesson folder name:\',j.lesson);if(lesson===null)return;lesson=lesson.trim();if(!lesson){notice(\'Please enter a lesson name\',true);return}let subject=prompt(\'Subject folder:\',j.subject);if(subject===null)return;subject=subject.trim();if(!subject){notice(\'Please enter a subject\',true);return}payload={action:\'edit\',id,lesson,subject};}if([\'cancel\',\'remove\'].includes(action)&&!confirm(`Are you sure you want to ${action} this queue item? Downloaded video files are not deleted.`))return;button.disabled=true;try{const x=await req(\'/api/action\',payload);notice(x.message||\'Updated\');await refresh()}catch(err){notice(err.message,true)}finally{button.disabled=false}});\nfunction subjectSummary(){if(!data)return;const stats={};data.jobs.forEach(j=>{const x=stats[j.subject]||(stats[j.subject]={total:0,done:0});x.total++;if(j.status===\'done\')x.done++;});$(\'subjectStats\').innerHTML=Object.keys(stats).length?Object.entries(stats).sort((a,b)=>b[1].total-a[1].total).map(([s,x])=>`<div style="margin:14px 0"><div class="row"><b>${esc(s)}</b><span class="meta">${x.done} / ${x.total} complete</span></div><div class="progress" style="height:6px;margin-top:9px"><i style="width:${Math.round(100*x.done/x.total)}%"></i></div></div>`).join(\'\'):\'<p class="small-note">Subject statistics appear after you add videos.</p>\'}\nfunction renderState(d){data=d;$(\'live\').classList.remove(\'off\');$(\'live\').textContent=\'SYSTEM ONLINE\';$(\'sideStatus\').textContent=\'Online\';$(\'sTotal\').textContent=d.counts.total;$(\'sDone\').textContent=d.counts.done;$(\'sActive\').textContent=d.counts.active;$(\'sQueued\').textContent=d.counts.queued;$(\'sFailed\').textContent=d.counts.failed+\' failed\';$(\'progressFailed\').textContent=d.counts.failed;$(\'overallPercent\').textContent=d.percent+\'%\';$(\'overallProgress\').style.width=d.percent+\'%\';$(\'progressSummary\').textContent=d.counts.done+\' / \'+d.counts.total;$(\'overallCount\').textContent=d.counts.queued+d.counts.active;$(\'sideFree\').textContent=fmt(d.free_bytes);$(\'diskFree\').textContent=fmt(d.free_bytes);$(\'settingsFree\').textContent=fmt(d.free_bytes);$(\'qualityView\').textContent=d.settings.quality+\'p\';$(\'rootPath\').textContent=d.folder;const speeds=(d.speeds||[]).join(\' + \');$(\'speedText\').innerHTML=speeds?esc(speeds):\'Idle <small>– no active transfer</small>\';if(!settingsReady){$(\'quality\').value=String(d.settings.quality);$(\'parallel\').value=String(d.settings.parallel);$(\'fragments\').value=String(d.settings.fragments);$(\'auto\').checked=!!d.settings.auto_start;settingsReady=true}renderJobs();subjectSummary();$(\'eventList\').innerHTML=(d.events||[]).length?d.events.map(e=>`<div class="log-item"><time>${esc(e.time.split(\' \').pop())}</time><span>${esc(e.text)}</span></div>`).join(\'\'):\'<div class="empty">No activity yet.</div>\'}\nlet fetching=false;async function refresh(){if(fetching)return;fetching=true;try{const r=await fetch(\'/api/state\',{cache:\'no-store\'});if(!r.ok)throw Error(`HTTP ${r.status}`);renderState(await r.json())}catch(e){$(\'live\').classList.add(\'off\');$(\'live\').textContent=\'DISCONNECTED\';$(\'sideStatus\').textContent=\'Offline\'}finally{fetching=false}}\nrefresh();setInterval(refresh,1900);\n</script>\n</body></html>\n'

class Handler(BaseHTTPRequestHandler):
    server_version = 'ALNexus/2.0'

    def log_message(self, format, *args):
        pass

    def json_reply(self, data, status=200, extra=None):
        body=json.dumps(data, ensure_ascii=False, default=str).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        if extra:
            for k,v in extra.items():self.send_header(k,v)
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def text_reply(self, body, mime='text/plain; charset=utf-8', status=200):
        body=body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type',mime)
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def is_local(self):
        return self.client_address[0] in ('127.0.0.1','::1')

    def valid_host(self):
        host=self.headers.get('Host','')
        try:
            parsed=urlparse('http://'+host)
            if parsed.port != PORT or not parsed.hostname or parsed.username:
                return False
            if parsed.hostname in ('localhost','127.0.0.1'):
                return self.is_local()
            ip=ipaddress.ip_address(parsed.hostname)
            return bool(LAN_MODE and ip.is_private and not ip.is_unspecified and not ip.is_loopback)
        except (ValueError,AttributeError):
            return False

    def authed(self):
        if self.is_local():
            return True
        for part in self.headers.get('Cookie','').split(';'):
            k, _, v=part.strip().partition('=')
            if k=='nexus_session' and hmac.compare_digest(v, SERVICE.session_id):
                return True
        return False

    def login_page(self):
        return """<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><meta name=theme-color content='#0b1020'><title>Nexus Pairing</title><style>*{box-sizing:border-box}body{display:grid;place-items:center;min-height:100vh;margin:0;background:radial-gradient(ellipse at 60% 0%,#2b2760,#080d18 60%);font:14px system-ui;color:#e8eeff}.box{max-width:390px;width:calc(100% - 32px);padding:33px;border:1px solid #374164;border-radius:22px;background:#141c30;box-shadow:0 22px 70px #0006}h1{margin:0 0 7px;font-size:24px}p{color:#b6c2df}input,button{width:100%;border-radius:10px;padding:13px;font:inherit}input{background:#0c1526;border:1px solid #485275;color:white;margin:14px 0}button{background:#7a77fa;border:0;color:white;font-weight:800;cursor:pointer}small{color:#8999b6}#err{color:#ff99ad;margin-top:9px;min-height:16px}</style><div class=box><div style='font-size:30px;margin-bottom:15px'>◇</div><h1>NEXUS PRO</h1><p>Private PC pairing. Enter the access code shown in your phone's Termux window.</p><form id=f><input id=c placeholder='Access code' required autocomplete=off autofocus><button>Connect to dashboard →</button></form><div id=err></div><small>Keep both devices on the same trusted Wi-Fi. No external hosting.</small></div><script>document.getElementById('f').onsubmit=async e=>{e.preventDefault();const err=document.getElementById('err');err.textContent='Connecting...';try{const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:document.getElementById('c').value.trim()})});const x=await r.json();if(!r.ok)throw Error(x.error||'Login failed');location.replace('/')}catch(ex){err.textContent=ex.message}}</script>"""

    def do_GET(self):
        if not self.valid_host():
            self.json_reply({'error':'Invalid host or network mode'},403);return
        target=urlparse(self.path)
        path=target.path
        if not self.authed():
            if path=='/':
                self.text_reply(self.login_page(),'text/html; charset=utf-8');return
            self.json_reply({'error':'PC pairing required'},401);return
        if path=='/':
            self.text_reply(DASHBOARD_HTML.replace('__INSERT_TOKEN__',SERVICE.token),'text/html; charset=utf-8')
        elif path=='/api/state':
            self.json_reply(SERVICE.snapshot())
        elif path=='/report.txt':
            snap=SERVICE.snapshot()
            rows=['A/L Nexus PRO — Report',now(),'',f"Total: {snap['counts']['total']}; done: {snap['counts']['done']}; failed: {snap['counts']['failed']}",'']
            for j in snap['jobs']:
                rows.append(f"{j['status'].upper()} | {j['subject']} / {j['lesson']} | {j['label']} | {j['url']} | {j.get('message','')}")
            self.text_reply('\n'.join(rows)+'\n')
        elif path=='/report.csv':
            output=io.StringIO()
            csvout=csv.writer(output)
            csvout.writerow(['Status','Subject','Lesson','Day','Video URL','Resolution','File','Message'])
            for j in SERVICE.snapshot()['jobs']:
                csvout.writerow([j['status'],j['subject'],j['lesson'],j['label'],j['url'],j.get('quality_override') or 'default',j.get('filename',''),j.get('message','')])
            self.text_reply('\ufeff'+output.getvalue(),'text/csv; charset=utf-8')
        elif path=='/favicon.ico':
            self.send_response(204);self.end_headers()
        else:
            self.json_reply({'error':'Not found'},404)

    def do_POST(self):
        if not self.valid_host():
            self.json_reply({'error':'Invalid host'},403);return
        origin=self.headers.get('Origin','')
        valid_origin='http://'+self.headers.get('Host','')
        if origin and origin!=valid_origin:
            self.json_reply({'error':'Invalid origin'},403);return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<=3_000_000:
                raise ValueError('Request is empty or too large (max 3 MB)')
            data=json.loads(self.rfile.read(size).decode('utf-8'))
            if not isinstance(data,dict):
                raise ValueError('Expected JSON object')
            path=urlparse(self.path).path
            if path=='/api/login' and not self.is_local() and LAN_MODE:
                peer=self.client_address[0]
                attempts=SERVICE.login_attempts.get(peer,[])
                attempts=[t for t in attempts if time.time()-t<60]
                if len(attempts)>=5:
                    SERVICE.login_attempts[peer]=attempts
                    self.json_reply({'error':'Too many attempts; try again in a minute'},429);return
                code=str(data.get('code','')).strip().upper()
                if not hmac.compare_digest(code,SERVICE.remote_code):
                    attempts.append(time.time())
                    SERVICE.login_attempts[peer]=attempts
                    self.json_reply({'error':'Incorrect pairing code'},403);return
                SERVICE.login_attempts.pop(peer,None)
                self.json_reply({'message':'Paired'},extra={'Set-Cookie':f'nexus_session={SERVICE.session_id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400'})
                return
            if not self.authed():
                self.json_reply({'error':'PC pairing required'},401);return
            if self.headers.get('X-App-Token')!=SERVICE.token:
                self.json_reply({'error':'Invalid dashboard session'},403);return
            if path=='/api/add':
                message=data.get('text','')
                if not isinstance(message,str):raise ValueError('Message must be text')
                result=SERVICE.add_message(message,data.get('subject'),data.get('lesson'),data.get('quality'))
            elif path=='/api/action':
                result={'message':SERVICE.action(data.get('action'),data.get('id'),data.get('subject'),data.get('lesson'))}
            elif path=='/api/settings':
                result={'message':SERVICE.set_settings(data)}
            else:
                self.json_reply({'error':'Unknown action'},404);return
            self.json_reply(result)
        except (ValueError,KeyError,TypeError) as e:
            self.json_reply({'error':str(e)},400)


def cli_loop():
    print('\nTERMUX INPUT MODE: Paste full messages and finish with DONE.')
    print('Use the browser dashboard to add new links at any time without interrupting downloads.')
    print('To exit completely: Ctrl+C in Termux.\n',flush=True)
    while SERVICE.running:
        lines=[]
        try:
            while True:
                line=input()
                if line.strip().upper()=='DONE':break
                lines.append(line)
            if not any(x.strip() for x in lines):
                print('No message pasted. Dashboard remains active.',flush=True)
                continue
            result=SERVICE.add_message('\n'.join(lines))
            print(f"Added {result['added']} link(s), skipped {result['duplicates']} duplicate(s).",flush=True)
            for group in result['groups']:
                print(f"  {group['subject']} / {group['lesson']} ({group['videos']})",flush=True)
            print('You can paste another message now, even while downloads continue.\n',flush=True)
        except EOFError:
            return
        except KeyboardInterrupt:
            return


def self_test():
    m1='''*🌍 A/L BIOLOGY | පාරිසරික ජීව විද්‍යාව (Environmental Biology) 🌱*
*📌 Unit 08: Full Lesson Pack*
*👤 දිනේෂ් මුතුගල සර් (Dinesh Muthugala)*
*Lesson Session - Day 01*
https://youtu.be/BzinLonGIPk?si=abcd
*Lesson Session - Day 02*
https://youtu.be/DaayAVji7oo?si=abcd
*Lesson Session - Day 03*
https://youtu.be/Lg19I6i_gWc?si=abcd
*Lesson Session - Day 04*
https://youtu.be/RPSlbZMqBjY?si=abcd
https://whatsapp.com/channel/0029Vb60NIU0AgW7lal6IN1p
'''
    m2='''A/L BIOLOGY | ප්‍රවේණිය (Genetics)
Day 01
https://www.youtube.com/watch?v=Zabcde12345
Day 02
https://youtu.be/Qabcde12345
'''
    v=parse_messages(m1+'\n'+m2+'\nDONE')
    assert len(v)==6, v
    assert [j['label'] for j in v[:4]]==['Day 01','Day 02','Day 03','Day 04']
    assert all(j['lesson'].startswith('පාරිසරික') for j in v[:4])
    assert all(j['lesson'].startswith('ප්‍රවේණිය') for j in v[4:])
    assert DownloadService._parse_progress('[download]  37.4% of 1.20GiB at 5.12MiB/s ETA 00:56')['progress']==37.4
    assert len(parse_messages(m1+m1))==4
    print('✓ Parsing multiple lessons, ignoring WhatsApp link, days, dedup, progress: PASSED')


def main():
    global SERVICE
    if '--self-test' in sys.argv:
        self_test();return
    try:
        import yt_dlp
    except ImportError:
        print('MISSING yt-dlp. Install once with: pip install -U yt-dlp',flush=True)
        return
    if not shutil.which('ffmpeg'):
        print('Warning: ffmpeg missing. Install once with: pkg install ffmpeg -y',flush=True)
    if not (Path.home()/'storage'/'downloads').exists():
        print('Warning: Android downloads folder not available. Run: termux-setup-storage',flush=True)
    ROOT.mkdir(parents=True,exist_ok=True)
    SERVICE=DownloadService()
    try:
        server=ThreadingHTTPServer(('0.0.0.0' if LAN_MODE else '127.0.0.1',PORT),Handler)
        server.daemon_threads = True
    except OSError as e:
        SERVICE.shutdown()
        print(f'Could not start dashboard on port {PORT}: {e}')
        print(f'If the downloader is already running, open http://127.0.0.1:{PORT}')
        return
    print('\n'+'='*56)
    print('  A/L NEXUS LIVE — PREMIUM BATCH DASHBOARD')
    print('  http://127.0.0.1:'+str(PORT))
    print('  Files: '+str(ROOT))
    print('  Quality: default 720p; select 1080p in Dashboard')
    if LAN_MODE:
        def get_lan_ip():
            s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            try:
                s.connect(('192.0.2.1',80))
                return s.getsockname()[0]
            except OSError:
                return 'PHONE_WIFI_IP'
            finally:
                s.close()
        print('  PC address (same trusted Wi-Fi): http://'+get_lan_ip()+':'+str(PORT))
        print('  PRIVATE PC ACCESS CODE: '+SERVICE.remote_code)
        print('  Do not enable router port forwarding or expose to public networks!')
    else:
        print('  PC access disabled. Start with --lan for same-Wi-Fi PC pairing.')
    print('  Add more links anytime while downloading — no restart!')
    print('='*56,flush=True)
    threading.Thread(target=cli_loop,daemon=True).start()
    # Termux usually includes termux-open-url; the URL also stays printed above.
    if shutil.which('termux-open-url'):
        try:
            subprocess.Popen(['termux-open-url',f'http://127.0.0.1:{PORT}'],
                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        except OSError:pass
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print('\nStopping (queue will be saved for next run).',flush=True)
    finally:
        SERVICE.shutdown()
        server.server_close()


if __name__=='__main__':
    main()
