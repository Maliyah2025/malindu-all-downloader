# Malindu All Downloader — GitHub APK Build Guide (Fast / Resume edition)

මෙම ZIP එක Android source project එකක්. **APK file එකක් නොවේ**. Phone එකෙන් GitHub Actions භාවිතයෙන් APK build කළ හැකිය. **මෙම ZIP එක පමණක් repository එකට දැම්මොත් build එක පටන් නොගනී**: repo root එකේ `.github/workflows/build.yml` workflow එකක් වෙනම Create new file කර paste කළ යුතුය.

## Update කළ functions

- Video/Reel/Shorts: YouTube, Facebook, TikTok, Instagram සහ yt-dlp support කරන අනෙකුත් sites. Site restrictions, login/DRM/anti-bot protection නිසා video කිහිපයක් fail විය හැක.
- Photo posts / carousel posts / Pinterest photos: images mode (gallery-dl).
- Link එක්ක වෙන වචන සහ Sinhala text තිබුණත් known site URLs auto-detect කිරීම.
- Large *direct* MP4 / files වල server එක HTTP byte-range requests support කරනවා නම් 1, 2, 4, 8, 12, 16 pieces වලට parallel download කර අවසානයේ එක file එකක් ලෙස merge කිරීම. Interrupted direct file parts නැවත පාවිච්චි කිරීම.
- yt-dlp DASH/HLS streams සඳහා `--concurrent-fragments` setting (source site එක සහ stream type එක අනුව වෙනස් වේ; ඕනෑම stream එකට arbitrarily split කරන්න බැහැ).
- Pause All, Resume All, Retry Failed All, Clear Completed; තනි job එකට Pause/Resume/Retry/Cancel; fragment count settings persist after restart.
- 360p–2160p max quality; thumbnail / audio / direct files; status/progress/speed/ETA, video partial files resume via yt-dlp.
- Android Share → app; Android Downloads → Malindu All Downloader file export.

Downloads වලට permission/rights තිබෙන media පමණක් භාවිතා කරන්න. සියලු වෙබ් අඩවි වල සියලු video links download වීම **guarantee නැත**. Speed = phone/network/server/file/fragment format මත වෙනස් වේ. `16 parts` සෑම විටම `8 parts` වලට වඩා වේගවත් නොවේ. App එක download කරන්නේ එක queue item එකක් පසු එකක්; ඒ item එක ඇතුළේ supported fragments parallel යයි.

## Phone එකෙන් GitHub වෙත upload කරන්න

1. Chrome → https://github.com/new → sign in → Repository name `malindu-all-downloader` → Public හෝ Private → **Add a README** enable → **Create repository**.
2. Repository main page (Code tab) එකේ file list ඉහළ `Add file` → `Upload files`. හොයාගන්න බැරි නම් Chrome ⋮ → **Desktop site** enable කරන්න.
3. **choose your files** → `Malindu_All_Downloader_Fast_Project.zip` තෝරන්න → පහළ **Commit changes**. ZIP එක extract කරන්න එපා.
4. **Add file → Create new file** → Filename `.github/workflows/build.yml`.
5. ChatGPT එක්ක දෙන `BUILD_APK_FROM_ZIP.yml` ගොනුවේ **ඇතුළත text එක** copy කර editor එකට paste කර **Commit changes** කරන්න. `.yml` file එක root එකට upload කරනවා වෙනුවට `.github/workflows/` path එකේ Create new file කරන්න.
6. Repository → **Actions** → `Build Malindu APK from ZIP` → **Run workflow** (push හින්දා auto-run විය හැක).
7. Green tick එකෙන් build succeeded නම් Run එක open කරන්න → **Artifacts** → `Malindu-Downloader-APK` → ZIP download කරන්න → extract → `app-debug.apk` tap කර install කරන්න.
8. Red ✗ නම් Actions → failed run → `Build APK` / අනෙක් failed step එකේ error screenshot ලබාගන්න; tested Python functions තිබුණත් actual Android build/device operation මෙතැන verify කරලා නැහැ.

## Tips

- `fragments = 8` පළමුව භාවිතා කරන්න; fail/slow නම් `4`, high-speed server සඳහා `12` හෝ `16` test කරන්න.
- Pause/Resume will keep .part or .segments files. Save space: clear downloads by deleting exported files and app-private partial files if needed.
- Private / DRM / paid videos සඳහා bypass feature එකක් නැහැ; authorized users can import their own Netscape cookies file in Settings. Cookies GitHub එකට upload කරන්න එපා.
- Android 10+ 64-bit ARM phones recommended; debug APK from GitHub must be installed manually. Updating app on the same phone requires compatible app signature; GitHub runners may generate a different signing key for every build, requiring uninstall/backup before installing the next build.
- Source is licensed per LICENSE.txt. Some bundled Android libraries are GPL-licensed; see THIRD_PARTY_NOTICES.md.
