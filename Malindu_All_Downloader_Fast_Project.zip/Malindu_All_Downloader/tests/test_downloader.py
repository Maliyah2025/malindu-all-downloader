import importlib.util, pathlib, tempfile, threading, time, json, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import requests
p=pathlib.Path(__file__).parents[1]/'app/src/main/python/malindu.py'
sys.path.insert(0,str(p.parent))
spec=importlib.util.spec_from_file_location('malindu',p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def test_mixed_message():
    text='මේක බලන්න🔥 https://youtu.be/abcdefghijk 😍 FB: facebook.com/share/v/abc/\nInsta www.instagram.com/reel/ABC/ TikTok https://vm.tiktok.com/ABCD/\n pin.it/ABCD'
    assert m.links(text)==['https://youtu.be/abcdefghijk','https://facebook.com/share/v/abc/','https://www.instagram.com/reel/ABC/','https://vm.tiktok.com/ABCD/','https://pin.it/ABCD']
def test_punctuation_and_adjacent():
    assert m.links('link(https://youtu.be/abcdefghijk),https://www.tiktok.com/@me/video/123🔥මේක') == ['https://youtu.be/abcdefghijk','https://www.tiktok.com/@me/video/123']
    assert len(m.links('https://youtu.be/abcdefghijkhttps://fb.watch/abc/'))==2
    assert m.links('[video](https://example.org/file_(1).mp4)')==['https://example.org/file_(1).mp4']
def test_dedup_entities_and_invalid():
    assert m.links('https://youtube.com/watch?v=abcdefghijk&amp;t=2 https://youtube.com/watch?v=abcdefghijk&t=2')==['https://youtube.com/watch?v=abcdefghijk&t=2']
    assert m.links('ftp://example.com https://user:pass@example.org/a')==[]
def test_routes_and_options():
    assert m.route('https://cdn.example/a.jpg?x=1','auto')=='direct'
    assert m.route('https://pin.it/x','auto')=='images'
    assert m.route('https://facebook.com/photo/?fbid=1','auto')=='images'
    assert m.route('https://youtu.be/abcdefghijk','auto')=='video'
    assert '--skip-download' in m.video_args('/tmp/x','thumbnail',720,False)
    assert '--audio-format' in m.video_args('/tmp/x','audio',720,False)
    assert m.safe_name('../../bad/name')=='_.._bad_name'

def test_end_to_end_direct_queue_auth_and_failure(tmp_path):
    class FileHandler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_GET(self):
            body=b'<html>login</html>' if self.path=='/page' else b'example download bytes'
            self.send_response(200);self.send_header('Content-Type','text/html' if self.path=='/page' else 'application/octet-stream');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    fileserver=ThreadingHTTPServer(('127.0.0.1',0),FileHandler)
    threading.Thread(target=fileserver.serve_forever,daemon=True).start()
    url=m.start(tmp_path/'data'); base=url.split('/?')[0]; headers={'X-Token':m.ENGINE.token}
    assert requests.get(base+'/state').status_code==403
    assert requests.post(base+'/add',json={}).status_code==403
    good=f'http://127.0.0.1:{fileserver.server_port}/file.zip'
    bad=f'http://127.0.0.1:{fileserver.server_port}/page'
    r=requests.post(base+'/add',headers=headers,json={'text':f'hello {good} and {bad}','mode':'direct','quality':720})
    assert r.status_code==200
    deadline=time.time()+10
    while time.time()<deadline:
        jobs=requests.get(base+'/state',headers=headers).json()['jobs']
        if all(j['status'] in ('done','failed') for j in jobs):break
        time.sleep(.1)
    assert [j['status'] for j in jobs]==['done','failed']
    assert 'web page' in jobs[1]['message']
    downloaded=list((tmp_path/'data/files').rglob('*.zip'))
    assert len(downloaded)==1 and downloaded[0].read_bytes()==b'example download bytes'
    assert len(json.loads((tmp_path/'data/queue.json').read_text()))==2
    assert requests.post(base+'/action',headers=headers,json={'action':'cookies','text':'bad'}).status_code==400
    fileserver.shutdown()


def test_original_lesson_recognition():
    jobs=m.parse_messages('A/L BIOLOGY | ප්‍රවේණිය (Genetics)\nDay 01\nhttps://youtu.be/abcdefghijk')
    assert len(jobs)==1 and jobs[0]['subject']=='Biology' and jobs[0]['label']=='Day 01'
    assert jobs[0]['lesson'].startswith('ප්‍රවේණිය')


def test_parallel_range_segments_pause_and_resume(tmp_path):
    from segmented import download
    from threading import Lock
    original = (b'0123456789abcdef' * (6 * 1024 * 1024 // 16 + 1))[:6 * 1024 * 1024]
    counts = []
    lock = Lock()

    class RangeHandler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass
        def do_GET(self):
            value = self.headers.get('Range', '')
            if value:
                import re
                m0 = re.fullmatch(r'bytes=(\d+)-(\d*)', value)
                begin = int(m0.group(1)); end = int(m0.group(2)) if m0.group(2) else len(original)-1
                body=original[begin:end+1]
                with lock: counts.append((begin,end))
                self.send_response(206)
                self.send_header('Content-Range', f'bytes {begin}-{end}/{len(original)}')
            else:
                body=original
                self.send_response(200)
            self.send_header('Content-Type','application/octet-stream')
            self.send_header('ETag','"stable123"')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            try:
                for i in range(0,len(body),65536):
                    self.wfile.write(body[i:i+65536])
                    self.wfile.flush()
                    time.sleep(.001)
            except (BrokenPipeError,ConnectionResetError): pass

    srv=ThreadingHTTPServer(('127.0.0.1',0),RangeHandler)
    threading.Thread(target=srv.serve_forever,daemon=True).start()
    target=tmp_path/'large.mp4'
    url=f'http://127.0.0.1:{srv.server_port}/large.mp4'
    cutoff = [0]
    def check():
        if cutoff[0] >= 2: raise RuntimeError('user paused')
    def progress(done,total,speed,eta):
        if done > 600000: cutoff[0] = 2
    try:
        import pytest
        with pytest.raises(RuntimeError,match='paused'):
            download(url,target,parts=4,progress=progress,check=check)
        assert (tmp_path/'large.mp4.segments').exists()
        download(url,target,parts=4)
        assert target.read_bytes()==original
        assert not (tmp_path/'large.mp4.segments').exists()
        assert any(start>0 for start,end in counts)
        assert len(counts)>4
    finally:
        srv.shutdown()


def test_batch_controls_and_settings(tmp_path):
    eng=m.Engine(tmp_path/'state')
    eng.paused_all = True
    eng.add({'text':'https://www.youtube.com/watch?v=abcdefghijk','quality':720,'mode':'video'})
    j=eng.jobs[0]
    assert j['status']=='queued'
    assert eng.action({'action':'settings','fragments':12})['message'].startswith('12')
    assert eng.settings['fragments']==12
    assert '--concurrent-fragments' in m.video_args('/tmp','video',720,False,fragments=12)
    eng.action({'action':'pause_all'})
    assert j['status']=='paused'
    eng.action({'action':'resume_all'})
    assert j['status']=='queued'
    eng.action({'action':'pause','id':j['id']})
    assert j['status']=='paused'
    eng.action({'action':'resume','id':j['id']})
    assert j['status']=='queued'
    j['status']='failed'
    assert '1 failed' in eng.action({'action':'retry_failed'})['message']
    assert j['status']=='queued'
    eng.action({'action':'cancel','id':j['id']})
    assert j['status']=='cancelled'
    eng.paused_all = True
