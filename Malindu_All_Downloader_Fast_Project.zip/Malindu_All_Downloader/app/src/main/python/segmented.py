"""Resumable HTTP byte-range downloads; fallback to single stream when Range is unavailable.

Only parallelize when the server explicitly supports byte ranges. Never infer range
support from Accept-Ranges alone. Saved segment files can be resumed later.
"""
import json
import re
import shutil
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests

CHUNK = 256 * 1024
HEADERS = {"User-Agent": "Mozilla/5.0 MalinduAllDownloader/1.1", "Accept-Encoding": "identity"}
TIMEOUT = (15, 30)


def _media_response(response):
    content_type = response.headers.get('Content-Type', '').split(';')[0].lower().strip()
    if content_type in ('text/html', 'application/xhtml+xml'):
        raise ValueError('This link returns a web page, not a direct file. Choose Video / Images mode.')


def _range_info(url):
    """GET one byte to verify Range and discover representation metadata."""
    with requests.get(url, headers=dict(HEADERS, Range='bytes=0-0'), stream=True, timeout=TIMEOUT) as r:
        r.raise_for_status()
        _media_response(r)
        match = re.fullmatch(r'bytes\s+0-0/(\d+)', r.headers.get('Content-Range', '').strip())
        total = int(match.group(1)) if r.status_code == 206 and match else 0
        if total <= 0: total = 0
        return total, r.headers.get('ETag', ''), r.headers.get('Last-Modified', '')


def download(url, target, parts=8, progress=None, check=None):
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    parts = max(1, min(16, int(parts)))
    check = check or (lambda: None)
    if target.exists() and target.stat().st_size > 0:
        if progress: progress(target.stat().st_size,target.stat().st_size,0,0)
        return target
    check()
    total, etag, modified = _range_info(url)
    if total and parts > 1 and total >= 2*1024*1024:
        # At least ~1MiB per worker to avoid creating very small requests.
        parts = min(parts, max(1, total//(1024*1024)))
        if parts >= 2:
            return _segmented(url, target, total, parts, etag, modified, progress, check)
    return _single(url, target, total, etag, modified, progress, check)


def _single(url, target, total, etag, modified, progress, check):
    part = target.with_name(target.name+'.part')
    done = part.stat().st_size if part.exists() else 0
    # Need verified total and range support to resume correctly.
    if not total or done >= total:
        if total and done == total:
            part.replace(target)
            return target
        if part.exists(): part.unlink()
        done = 0
    headers = dict(HEADERS)
    if done:
        headers['Range'] = f'bytes={done}-'
        if etag or modified: headers['If-Range'] = etag or modified
    with requests.get(url, stream=True, headers=headers, timeout=TIMEOUT) as r:
        r.raise_for_status(); _media_response(r)
        if done:
            expected = f'bytes {done}-'
            if r.status_code != 206 or not r.headers.get('Content-Range','').startswith(expected):
                # Server ignored resume, or representation changed: start clean.
                return _single_fresh(url,target,progress,check)
        elif r.status_code not in (200,206):
            raise ValueError('Unexpected HTTP response')
        reported_total = total or int(r.headers.get('Content-Length', 0))
        start = time.monotonic(); recent=0; last=0
        with part.open('ab' if done else 'wb') as out:
            for chunk in r.iter_content(CHUNK):
                check()
                if not chunk: continue
                out.write(chunk); done += len(chunk); recent += len(chunk)
                elapsed=max(.001, time.monotonic()-start)
                if progress and (time.monotonic()-last>.35):
                    speed=recent/elapsed
                    progress(done,reported_total,speed,(reported_total-done)/speed if speed and reported_total else 0)
                    last=time.monotonic()
    check()
    if reported_total and done != reported_total:
        raise IOError(f'Incomplete download: {done}/{reported_total} bytes')
    part.replace(target)
    if progress: progress(done,done,0,0)
    return target


def _single_fresh(url,target,progress,check):
    target.with_name(target.name+'.part').unlink(missing_ok=True)
    return _single(url,target,0,'','',progress,check)


def _segmented(url, target, total, workers, etag, modified, progress, check):
    parts_dir=target.with_name(target.name+'.segments')
    meta_file=parts_dir/'metadata.json'
    metadata={'url':url,'total':total,'workers':workers,'etag':etag,'modified':modified}
    if parts_dir.exists():
        try: old=json.loads(meta_file.read_text('utf-8'))
        except (OSError,ValueError): old=None
        if old!=metadata: shutil.rmtree(parts_dir)
    parts_dir.mkdir(parents=True,exist_ok=True)
    meta_file.write_text(json.dumps(metadata),'utf-8')
    ranges=[]
    for i in range(workers):
        start=(total*i)//workers
        end=(total*(i+1))//workers - 1
        ranges.append((start,end,parts_dir/f'{i:03}.part'))
    # If a range was truncated or corrupted on a previous attempt, reset that part.
    for start,end,p in ranges:
        if p.exists() and p.stat().st_size > end-start+1: p.unlink()
    start_time=time.monotonic()
    lock=threading.RLock()
    downloaded=sum(p.stat().st_size if p.exists() else 0 for _,_,p in ranges)
    base_downloaded=downloaded
    last_notify=0.0

    def update(inc):
        nonlocal downloaded,last_notify
        with lock:
            downloaded+=inc
            clock=time.monotonic()
            if progress and (clock-last_notify>.35 or downloaded>=total):
                elapsed=max(.001,clock-start_time)
                speed=max(0,(downloaded-base_downloaded)/elapsed)
                progress(downloaded,total,speed,(total-downloaded)/speed if speed else 0)
                last_notify=clock

    def transfer(entry):
        start,end,p=entry
        expected=end-start+1
        existing=p.stat().st_size if p.exists() else 0
        if existing==expected: return
        first=start+existing
        headers=dict(HEADERS,Range=f'bytes={first}-{end}')
        if etag or modified: headers['If-Range']=etag or modified
        for attempt in range(5):
            check()
            existing=p.stat().st_size if p.exists() else 0
            first=start+existing
            if existing == expected: return
            headers['Range']=f'bytes={first}-{end}'
            try:
                with requests.get(url,stream=True,timeout=TIMEOUT,headers=headers) as r:
                    r.raise_for_status(); _media_response(r)
                    m=re.fullmatch(r'bytes\s+(\d+)-(\d+)/(\d+)',r.headers.get('Content-Range','').strip())
                    if r.status_code!=206 or not m or (int(m[1]),int(m[2]),int(m[3]))!=(first,end,total):
                        raise ValueError('Server changed or ignored HTTP Range. Cannot safely join parts.')
                    with p.open('ab') as out:
                        for chunk in r.iter_content(CHUNK):
                            check()
                            if not chunk: continue
                            if p.stat().st_size + len(chunk)>expected: raise ValueError('Segment exceeded expected bytes')
                            out.write(chunk); update(len(chunk))
                if p.stat().st_size==expected: return
                raise IOError('Range transfer ended early')
            except (requests.RequestException,IOError):
                if attempt==4: raise
                time.sleep(min(2**attempt,6))
        if p.stat().st_size!=expected: raise IOError('Incomplete segment')

    try:
        with ThreadPoolExecutor(max_workers=workers,thread_name_prefix='dl-part') as pool:
            futures=[pool.submit(transfer,entry) for entry in ranges]
            for future in as_completed(futures):
                future.result()
        check()
        # Verify exact bytes before joining. Partial segments remain after failures.
        for start,end,p in ranges:
            if not p.is_file() or p.stat().st_size!=end-start+1: raise IOError('A segment is incomplete')
        merging=target.with_name(target.name+'.part')
        with merging.open('wb') as out:
            for _,_,p in ranges:
                check()
                with p.open('rb') as stream: shutil.copyfileobj(stream,out,1024*1024)
        if merging.stat().st_size!=total: raise IOError('Merged file length does not match')
        merging.replace(target)
        shutil.rmtree(parts_dir)
        if progress: progress(total,total,0,0)
        return target
    except Exception:
        # Preserve each completed segment for the next retry / resume action.
        raise
