#!/usr/bin/env python3
"""Malindu All Downloader. Python/Termux dashboard and embedded Android engine."""
import hashlib, html, json, mimetypes, os, re, secrets, shutil, subprocess, sys, threading, time
from pathlib import Path
from urllib.parse import urlparse, unquote
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

URL_RX = re.compile(r'https?://[^\s<>"\x27]+', re.I)
MODES = ('auto', 'video', 'images', 'thumbnail', 'audio', 'direct')
DIRECT = {'.jpg','.jpeg','.png','.webp','.gif','.avif','.mp4','.webm','.mov','.mp3','.m4a','.wav','.pdf','.zip'}
def safe_name(s):
    s = re.sub(r'[\\/<>:"|?*\x00-\x1f]', '_', str(s)).strip(' .')
    return s.encode('utf8')[:160].decode('utf8','ignore') or 'Download'
SOCIAL = r'(?:www\.)?(?:(?:m|mobile|vm|vt|web|l|music)\.)?(?:youtube\.com|youtu\.be|facebook\.com|fb\.watch|fb\.com|tiktok\.com|instagram\.com|pinterest\.[a-z.]+|pin\.it|twitter\.com|x\.com|reddit\.com|redd\.it|vimeo\.com|dailymotion\.com|dai\.ly|twitch\.tv|threads\.net|threads\.com|snapchat\.com|soundcloud\.com|bsky\.app)'
LINK_RX = re.compile(r'https?://[^\s<>"\x27]+|(?<![\w@/])(?:'+SOCIAL+r'|www\.[a-z0-9.-]+)(?:/[^\s<>"\x27]*)?', re.I)
def links(text):
    # Split common copy/paste delimiters and adjacent URLs; captions need no cleanup.
    text = html.unescape(str(text)).replace('\u200b',' ').replace('\ufeff',' ')
    text = re.sub(r'(?<!^)(?=https?://)', ' ', text)
    text = re.sub(r'[,;|](?=(?:https?://|www\.|'+SOCIAL+'))',' ',text,flags=re.I)
    result=[]
    for match in LINK_RX.finditer(text):
        u=match.group()
        if not re.match(r'^https?://',u,re.I): u='https://'+u
        # Social share URLs are ASCII. Strip adjoining Sinhala captions and emojis.
        if re.match(r'https?://'+SOCIAL+r'(?:/|$)',u,re.I):
            u=re.split(r'[^\x21-\x7e]',u)[0]
        u=u.rstrip('.,;!*]}|')
        while u.endswith(')') and u.count(')')>u.count('('): u=u[:-1]
        try:
            p=urlparse(u)
            if not p.hostname or p.username: continue
            p.port
        except ValueError: continue
        if u not in result: result.append(u)
    return result

def route(url, mode):
    if mode != 'auto': return mode
    p=urlparse(url); host=(p.hostname or '').lower()
    if Path(p.path).suffix.lower() in DIRECT: return 'direct'
    if (host.endswith('instagram.com') and p.path.lower().startswith(('/reel/', '/reels/', '/tv/'))): return 'video'
    if any(host == x or host.endswith('.'+x) for x in ('instagram.com','pinterest.com','pin.it','flickr.com','imgur.com','deviantart.com')): return 'images'
    if host.endswith('facebook.com') and ('photo' in p.path or 'photo' in p.query): return 'images'
    return 'video'

def video_args(folder, mode, quality, playlist, cookie='', fragments=8):
    a=['--ignore-config','--newline','--no-colors','--continue','--no-overwrites','--socket-timeout','30','--retries','10','--fragment-retries','10',
       '--file-access-retries','10','--retry-sleep','fragment:exp=1:10:2',
       '--concurrent-fragments',str(max(1,min(16,int(fragments)))),
       '--yes-playlist' if playlist else '--no-playlist','--playlist-end','100','-P',str(folder),'-o','%(title).100B [%(id)s].%(ext)s']
    if cookie: a += ['--cookies',cookie]
    if mode == 'thumbnail': a += ['--skip-download','--write-thumbnail']
    elif mode == 'audio': a += ['-f','bestaudio/best','-x','--audio-format','mp3']
    else: a += ['-f',f'bv*[height<={quality}]+ba/b[height<={quality}]','--merge-output-format','mp4']
    return a

class Engine:
    def __init__(self, root, native=None):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
        self.native=native; self.token=secrets.token_urlsafe(32); self.lock=threading.RLock()
        self.jobs=[]; self.proc=None; self.active=None; self.cancelled=set()
        self.paused_ids=set(); self.resume_after_stop=set(); self.paused_all=False
        self.settings_file=self.root/'settings.json'; self.settings={'fragments':8}
        try: self.settings.update(json.loads(self.settings_file.read_text('utf8')))
        except (OSError,ValueError,TypeError): pass
        self.settings['fragments']=max(1,min(16,int(self.settings.get('fragments',8))))
        self.state=self.root/'queue.json'; self.cookie=self.root/'cookies.txt'
        try: self.jobs=json.loads(self.state.read_text('utf8'))
        except (OSError,ValueError): pass
        for j in self.jobs:
            if j['status'] in ('running','queued','pausing'): j['status']='paused'; j['message']='Interrupted. Tap Resume to continue.'
        threading.Thread(target=self.worker,daemon=True).start()
    def save(self):
        with self.lock:
            tmp=self.state.with_suffix('.tmp'); tmp.write_text(json.dumps(self.jobs,ensure_ascii=False),'utf8'); tmp.replace(self.state)
            stmp=self.settings_file.with_suffix('.tmp'); stmp.write_text(json.dumps(self.settings),'utf8'); stmp.replace(self.settings_file)
    def snapshot(self):
        with self.lock: return {'jobs':json.loads(json.dumps(self.jobs)), 'folder':str(self.root/'files'), 'android':bool(self.native),'cookies':self.cookie.exists(), 'settings':dict(self.settings),'paused_all':self.paused_all}
    def add(self, data):
        mode=data.get('mode','auto'); quality=int(data.get('quality',720))
        if mode not in MODES or quality not in (360,480,720,1080,2160): raise ValueError('Invalid mode or quality')
        urls=links(str(data.get('text','')))
        if not urls: raise ValueError('Paste at least one http/https link.')
        if len(urls)>100: raise ValueError('Maximum 100 links per batch.')
        lesson_map={get_youtube_id(x['url']):x for x in parse_messages(str(data.get('text','')))}
        n=0
        with self.lock:
            for u in urls:
                if any(j['url']==u and j['mode']==mode and j['quality']==quality and j['status'] in ('queued','running') for j in self.jobs): continue
                lesson=lesson_map.get(get_youtube_id(u),{})
                detected=' - '.join(lesson.get(k,'') for k in ('subject','lesson','label')) if lesson.get('lesson','Unsorted')!='Unsorted' else 'Downloads'
                self.jobs.append(dict(id=secrets.token_hex(8),url=u,mode=mode,quality=quality,playlist=bool(data.get('playlist')),status='queued',progress=0,message='Waiting',folder=safe_name(data.get('folder') or detected))); n+=1
            self.save()
        return {'message':f'{n} links added'}
    def _stop_running(self, j):
        if self.native:
            try: self.native.cancel(j['id'])
            except Exception: pass
        if self.proc and self.proc.poll() is None:
            try: self.proc.terminate()
            except OSError: pass

    def _pause_job(self, j):
        if j['status']=='queued':
            j.update(status='paused',message='Paused')
        elif j['status']=='running':
            self.paused_ids.add(j['id'])
            j.update(status='paused',message='Pausing; partial files kept')
            self._stop_running(j)

    def _resume_job(self, j):
        if j['status'] not in ('paused','pausing'): return
        if self.active and self.active['id']==j['id'] and j['id'] in self.paused_ids:
            self.resume_after_stop.add(j['id'])
            j['message']='Resuming when current transfer stops'
        else:
            self.paused_ids.discard(j['id'])
            j.update(status='queued',message='Queued to resume')

    def action(self,data):
        action=data.get('action')
        with self.lock:
            if action=='cookies':
                value=str(data.get('text',''))
                if value:
                    if 'Netscape HTTP Cookie File' not in value[:200]: raise ValueError('Use Netscape cookies.txt format')
                    self.cookie.write_text(value,'utf8'); self.cookie.chmod(0o600)
                else: self.cookie.unlink(missing_ok=True)
                return {'message':'Cookies updated'}
            if action=='settings':
                fragments=int(data.get('fragments',self.settings['fragments']))
                if not 1<=fragments<=16: raise ValueError('Parts must be 1–16')
                self.settings['fragments']=fragments; self.save()
                return {'message':f'{fragments} concurrent parts selected for new downloads'}
            if action=='pause_all':
                self.paused_all=True
                for j in self.jobs: self._pause_job(j)
                self.save(); return {'message':'All downloads paused. Partial files are kept.'}
            if action=='resume_all':
                self.paused_all=False
                for j in self.jobs: self._resume_job(j)
                self.save(); return {'message':'Paused downloads queued to resume.'}
            if action=='retry_failed':
                count=0
                for j in self.jobs:
                    if j['status']=='failed':
                        self.cancelled.discard(j['id'])
                        j.update(status='queued',message='Retry queued',progress=0)
                        count+=1
                self.save(); return {'message':f'{count} failed downloads queued again'}
            if action=='clear_done':
                count=sum(j['status']=='done' for j in self.jobs)
                self.jobs=[j for j in self.jobs if j['status']!='done']
                self.save(); return {'message':f'Cleared {count} completed queue entries. Files kept.'}
            j=next((j for j in self.jobs if j['id']==data.get('id')),None)
            if not j: raise ValueError('Unknown download')
            if action=='retry':
                if j['status'] not in ('running','queued'):
                    self.cancelled.discard(j['id'])
                    self._resume_job(j)
                    if j['status'] not in ('running','queued','paused'):
                        j.update(status='queued',message='Retry queued',progress=0)
                    elif j['status']=='paused' and j['id'] not in self.resume_after_stop:
                        j.update(status='queued',message='Retry queued',progress=0)
            elif action=='pause': self._pause_job(j)
            elif action=='resume': self._resume_job(j)
            elif action=='cancel':
                self.cancelled.add(j['id']); self.resume_after_stop.discard(j['id'])
                if j['status'] in ('running','paused') and self.active and self.active['id']==j['id']:
                    self._stop_running(j); j['message']='Stopping; partial files kept'
                else: j.update(status='cancelled',message='Cancelled')
            else: raise ValueError('Unknown action')
            self.save()
        return {'message':'Updated'}
    def check(self,j):
        if j['id'] in self.cancelled: raise RuntimeError('Cancelled')
        if j['id'] in self.paused_ids: raise RuntimeError('Paused')
    def progress(self,j,text,percent=None):
        with self.lock:
            j['message']=str(text)[-800:]
            if percent is not None: j['progress']=max(0,min(100,float(percent)))
    def video(self,j,folder,mode):
        args=video_args(folder,mode,j['quality'],j['playlist'],str(self.cookie) if self.cookie.exists() else '',self.settings['fragments'])
        if self.native:
            self.native.video(j['url'],json.dumps(args),j['id'])
        else:
            # Node installed by the supplied Termux setup provides YouTube challenge support.
            if shutil.which('node'): args += ['--js-runtimes','node']
            cmd=[sys.executable,'-m','yt_dlp',*args,j['url']]
            self.proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            try:
                for line in self.proc.stdout:
                    self.check(j); m=re.search(r'(\d+(?:\.\d+)?)%',line)
                    self.progress(j,line.strip(),float(m[1]) if m else None)
                if self.proc.wait()!=0: raise RuntimeError(j['message'])
            finally:
                if self.proc.poll() is None: self.proc.terminate()
                self.proc.wait(); self.proc=None
    def images(self,j,folder):
        from gallery_dl import config, job
        config.clear()
        config.set(('extractor',),'base-directory',str(folder))
        config.set(('extractor',),'directory',[])
        config.set(('extractor',),'filename','{category}_{id}_{num}.{extension}')
        config.set(('extractor',),'retries',3)
        config.set(('extractor',),'timeout',30)
        config.set(('extractor',),'videos',j['mode']=='auto')
        config.set(('extractor',),'image-range','1-100')
        config.set(('extractor',),'post-range','1-100')
        config.set(('extractor',),'metadata',False)
        if self.cookie.exists(): config.set(('extractor',),'cookies',str(self.cookie))
        owner=self
        class GalleryJob(job.DownloadJob):
            def handle_url(self,url,kwdict):
                owner.check(j); owner.progress(j,'Downloading image '+str(kwdict.get('num','')))
                return super().handle_url(url,kwdict)
        task=GalleryJob(j['url']); code=task.run()
        if code: raise RuntimeError(f'Image extractor failed ({code}). Try your own cookies, or Video mode for reels.')
    def direct(self,j,folder):
        # HTTP Range segmented download: each chunk is individually resumable.
        # Servers without byte-range support use a safe single-stream fallback.
        from segmented import download
        url=j['url']
        name=safe_name(unquote(Path(urlparse(url).path).name))
        if not Path(name).suffix: name += '.bin'
        name=hashlib.sha256(url.encode()).hexdigest()[:10]+'_'+name
        target=folder/name
        def update(done,total,speed,eta):
            percent=100.0*done/total if total else 0
            self.progress(j, f'{done/1048576:.1f} / {total/1048576:.1f} MB  |  {speed/1048576:.2f} MB/s  |  ETA {eta:.0f}s' if total else f'{done/1048576:.1f} MB', percent)
        download(url,target,parts=self.settings['fragments'],progress=update,check=lambda:self.check(j))
    def worker(self):
        while True:
            with self.lock:
                j=next((j for j in self.jobs if j['status']=='queued'),None) if not self.paused_all else None
                if j: j.update(status='running',message='Starting…'); self.active=j; self.save()
            if not j: time.sleep(.3); continue
            try:
                folder=self.root/'files'/j['folder']/j['id']; folder.mkdir(parents=True,exist_ok=True)
                mode=route(j['url'],j['mode']); self.check(j)
                if mode=='direct': self.direct(j,folder)
                elif mode=='images':
                    try:
                        self.images(j,folder)
                        if not any(p.is_file() and p.suffix not in ('.part','.ytdl','.tmp','.sqlite3','.sqlite3-shm','.sqlite3-wal') for p in folder.rglob('*')): raise RuntimeError('No images found')
                    except Exception:
                        self.check(j)
                        if j['mode']!='auto': raise
                        self.video(j,folder,'video')
                else:
                    # A failed video must remain failed, not silently appear as
                    # a successful thumbnail or cover-image download.
                    self.video(j,folder,mode)
                self.check(j)
                files=[p for p in folder.rglob('*') if p.is_file() and p.suffix not in ('.part','.ytdl','.tmp','.sqlite3','.sqlite3-shm','.sqlite3-wal')]
                if not files: raise RuntimeError('No media found. Try another mode or import your own login cookies.')
                if self.native: self.native.exportFiles(str(folder))
                j.update(status='done',progress=100,message=f'{len(files)} file(s) saved'+(' to Download/Malindu All Downloader' if self.native else f' in {folder}'))
            except Exception as e:
                j.update(status=('paused' if j['id'] in self.paused_ids else 'cancelled' if j['id'] in self.cancelled else 'failed'),message=str(e)[-1200:])
            finally:
                with self.lock:
                    if j['id'] in self.resume_after_stop and j['id'] not in self.cancelled:
                        j.update(status='queued',message='Resuming paused transfer')
                    self.resume_after_stop.discard(j['id']); self.paused_ids.discard(j['id'])
                    self.active=None; self.save()

ENGINE=None
SERVER=None
def native_progress(jid,percent,text):
    if ENGINE and ENGINE.active and ENGINE.active['id']==jid: ENGINE.progress(ENGINE.active,text,percent)

def start(root,native=None):
    global ENGINE,SERVER
    if SERVER: return f'http://127.0.0.1:{SERVER.server_port}/?token={ENGINE.token}'
    ENGINE=Engine(root,native)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*a): pass
        def reply(self,obj,status=200,mime='application/json'):
            b=(json.dumps(obj,ensure_ascii=False) if mime=='application/json' else obj).encode()
            self.send_response(status); self.send_header('Content-Type',mime+'; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(b)
        def do_GET(self):
            from urllib.parse import parse_qs
            token=self.headers.get('X-Token') or parse_qs(urlparse(self.path).query).get('token',[''])[0]
            if not secrets.compare_digest(token,ENGINE.token): self.reply({'error':'Invalid session'},403); return
            if urlparse(self.path).path=='/': self.reply(PAGE.replace('__TOKEN__',ENGINE.token),mime='text/html')
            elif urlparse(self.path).path=='/state': self.reply(ENGINE.snapshot())
            else: self.reply({'error':'Not found'},404)
        def do_POST(self):
            if not secrets.compare_digest(self.headers.get('X-Token',''),ENGINE.token): self.reply({'error':'Invalid session'},403); return
            try:
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<1000000: raise ValueError('Request too large or empty')
                data=json.loads(self.rfile.read(n))
                if not isinstance(data,dict): raise ValueError('Expected object')
                if self.path=='/add': result=ENGINE.add(data)
                elif self.path=='/action': result=ENGINE.action(data)
                else: raise ValueError('Unknown action')
                self.reply(result)
            except Exception as e: self.reply({'error':str(e)},400)
    SERVER=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=SERVER.serve_forever,daemon=True).start()
    return f'http://127.0.0.1:{SERVER.server_port}/?token={ENGINE.token}'

PAGE='''<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#121626"><title>Malindu All Downloader</title><style>
*{box-sizing:border-box}body{margin:0;background:#101321;color:#f4f5ff;font:15px system-ui}main{max-width:900px;margin:auto;padding:24px 18px}h1{font-size:29px;letter-spacing:-1px;margin:8px 0}p{color:#aab3cd;line-height:1.6}.brand{font-size:11px;color:#ff9daa;letter-spacing:3px;font-weight:800}.card{background:#1c2235;border:1px solid #303b55;border-radius:20px;padding:20px;margin:18px 0}textarea,input,select{width:100%;background:#101625;color:#fff;border:1px solid #46516b;border-radius:10px;padding:12px;font:inherit;margin:8px 0}textarea{min-height:120px;resize:vertical}.row{display:flex;gap:12px}.row>*{flex:1;min-width:0}button{border:0;border-radius:10px;padding:13px 18px;background:#ee4260;color:#fff;font-weight:750;margin:6px 5px 6px 0;cursor:pointer}.secondary{background:#35415d}label,small{font-size:12px;color:#b4bfd9}input[type=checkbox]{width:auto}.job{border-top:1px solid #36415a;padding:15px 0;overflow-wrap:anywhere}.status{color:#ffb7c3;font-weight:700;font-size:12px;text-transform:uppercase}.url{font-size:13px;margin:8px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}progress{width:100%;accent-color:#ee4260}#notice{color:#ffd29b;white-space:pre-wrap}summary{cursor:pointer;color:#c5cee3}a{color:#ffb3c0}</style></head><body><main><span class=brand>MALINDU / MEDIA TOOLS</span><h1>All Downloader<span style="color:#ee4260">.</span></h1><p>Videos, reels, shorts, photos, thumbnails & files.<br>Paste a link. Choose a mode. Save it.</p><section class=card><label>LINKS — one or more, or paste a full message</label><textarea id=text placeholder="https://…"></textarea><div class=row><div><label>DOWNLOAD MODE</label><select id=mode><option value=auto>Auto detect</option><option value=video>Video / Reels / Shorts</option><option value=images>Images / Carousel / Post</option><option value=thumbnail>Video thumbnail</option><option value=audio>Audio → MP3</option><option value=direct>Direct file / PDF / ZIP</option></select></div><div><label>MAX VIDEO QUALITY</label><select id=quality><option>360</option><option>480</option><option selected>720</option><option>1080</option><option>2160</option></select></div></div><div class=row><div><label>PARALLEL PARTS (fast / resume)</label><select id=fragments><option value=1>1 (stable)</option><option value=2>2 parts</option><option value=4>4 parts</option><option value=8 selected>8 parts (recommended)</option><option value=12>12 parts</option><option value=16>16 parts (maximum)</option></select></div><div><label>Download settings</label><button class=secondary id=saveSettings>Save parts</button></div></div><small>HTTP Range direct files split into independent parts. DASH/HLS video streams use concurrent fragments where supported. More parts do not always mean more speed.</small><input id=folder placeholder="Folder / lesson name (optional)"><label><input id=playlist type=checkbox> Allow playlist (up to 100 entries)</label><br><button id=add>Download links ↓</button><button class=secondary id=paste>Paste</button><p id=notice></p></section><section class=card><h3>Download queue</h3><div><button class=secondary id=pauseAll>Pause All</button><button id=resumeAll>Resume All</button><button id=retryAll>Retry Failed All</button><button class=secondary id=clearDone>Clear Completed</button></div><small id=path></small><div id=jobs></div></section><details class=card><summary>Login cookies & help</summary><p>YouTube, Facebook, TikTok, Instagram, Pinterest and more depend on the site's extractor. For Facebook photo posts choose Images. Text-only posts are not media. Private/login-only content needs your own authorized cookies; DRM is not supported.</p><p>Paste a Netscape cookies.txt file below. Cookies stay on this device. Never send them with your APK or put them in a public repository.</p><textarea id=cookies placeholder="# Netscape HTTP Cookie File"></textarea><button id=saveCookies>Save cookies</button><button class=secondary id=clearCookies>Remove cookies</button><p id=cookieStatus></p><p>Keep the app running. Interrupted jobs can be resumed. Partial direct downloads and supported video fragments can resume. Image cancellation happens between files. Quality is limited by the original media. For large playlists, download smaller batches.</p></details><p style="font-size:12px">Download content you own or have permission to save. No paid server or Termux needed for the APK.</p></main><script>
const token='__TOKEN__',$=id=>document.getElementById(id);const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));async function api(p,data){let r=await fetch(p,{method:data?'POST':'GET',headers:{'X-Token':token,'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined});let x=await r.json();if(!r.ok)throw Error(x.error);return x}function notice(s){$('notice').textContent=s}async function send(p,d){try{notice((await api(p,d)).message);refresh()}catch(e){notice(e.message)}}$('saveSettings').onclick=()=>send('/action',{action:'settings',fragments:Number($('fragments').value)});$('pauseAll').onclick=()=>send('/action',{action:'pause_all'});$('resumeAll').onclick=()=>send('/action',{action:'resume_all'});$('retryAll').onclick=()=>send('/action',{action:'retry_failed'});$('clearDone').onclick=()=>send('/action',{action:'clear_done'});$('add').onclick=()=>send('/add',{text:$('text').value,mode:$('mode').value,quality:Number($('quality').value),folder:$('folder').value,playlist:$('playlist').checked});$('paste').onclick=async()=>{try{$('text').value=await navigator.clipboard.readText()}catch(e){notice('Long-press inside the link box and tap Paste.')}};$('saveCookies').onclick=()=>{send('/action',{action:'cookies',text:$('cookies').value});$('cookies').value=''};$('clearCookies').onclick=()=>send('/action',{action:'cookies',text:''});$('jobs').onclick=e=>{const b=e.target.closest('button[data-id]');if(b)send('/action',{action:b.dataset.action,id:b.dataset.id})};let busy=false,settingsInitialized=false;async function refresh(){if(busy)return;busy=true;try{let s=await api('/state');$('path').textContent=s.android?'Saved files: Download / Malindu All Downloader':s.folder;if(!settingsInitialized){$('fragments').value=String(s.settings.fragments);settingsInitialized=true;}$('cookieStatus').textContent=s.cookies?'Cookies saved on this device.':'No login cookies saved.';$('jobs').innerHTML=s.jobs.slice().reverse().map(j=>`<div class=job><span class=status>${esc(j.status)} · ${esc(j.mode)}</span><div class=url>${esc(j.url)}</div><progress max=100 value="${j.progress}"></progress><p>${esc(j.message)}</p><button class=secondary data-id="${j.id}" data-action="${j.status==='running'?'pause':j.status==='paused'?'resume':j.status==='queued'?'pause':'retry'}">${j.status==='running'?'Pause':j.status==='paused'?'Resume':j.status==='queued'?'Pause':'Retry'}</button><button class=secondary data-id="${j.id}" data-action="cancel">Cancel</button></div>`).join('')||'<p>No downloads yet.</p>'}catch(e){notice('Connection lost. Reopen the app to reconnect.')}finally{busy=false}}window.addSharedText=s=>{$('text').value=s};refresh();setInterval(refresh,1800);
</script></body></html>'''

# Preserve original Sinhala lesson/day recognition for pasted YouTube lesson packs.
import unicodedata
from collections import Counter
from datetime import datetime
from urllib.parse import parse_qs
DEFAULT_SUBJECT="Other"
DEFAULT_LESSON="Unsorted"
SUBJECTS = {
    "biology": "Biology", "bio": "Biology", "ජීව විද්‍යාව": "Biology",
    "chemistry": "Chemistry", "chem": "Chemistry", "රසායන විද්‍යාව": "Chemistry",
    "physics": "Physics", "phy": "Physics", "භෞතික විද්‍යාව": "Physics",
    "combined maths": "Combined Maths", "mathematics": "Combined Maths",
    "සංයුක්ත ගණිතය": "Combined Maths",
}
SUBJECT_HEADER = re.compile(
    r"(?i)(?:\ba\s*/\s*l\s*|\ba\.?l\.?\s*|\badvanced\s+level\s*)"
    r"(biology|chemistry|physics|combined\s+maths|mathematics|bio|chem|phy)\b"
)
BARE_SUBJECT_HEADER = re.compile(
    r"(?i)^\s*(biology|chemistry|physics|combined\s+maths|mathematics)\s*(?:[|:–—-]|$)"
)
LESSON_PATTERNS = [
    r"පාරිසරික\s+ජීව\s*විද්‍යාව", r"ප්‍රවේණිය", r"සෛල(?:ීය)?\s+ජීව\s*විද්‍යාව",
    r"ජීවයේ\s+රසායනික\s+පදනම", r"ජෛව\s*විවිධත්වය",
    r"අණුක\s+ජීව\s*විද්‍යාව", r"ක්ෂුද්‍ර\s+ජීව\s*විද්‍යාව",
    r"පරිණාමය", r"ජීවීන්ගේ\s+සංවිධානය", r"ශාක\s+පටක", r"සත්ත්ව\s+පටක",
    r"රසායනික\s+ගණනය", r"වායු", r"ශක්ති\s*විද්‍යාව", r"පරමාණුක\s+ව්‍යුහය",
    r"ව්‍යුහය\s+හා\s+බන්ධන", r"දෝලන\s+හා\s+තරංග",
    r"environmental\s+biology", r"ecology", r"genetics", r"cell\s+biology",
    r"evolution", r"microbiology", r"biochemistry", r"chemical\s+calculations",
    r"thermodynamics", r"organic\s+chemistry", r"inorganic\s+chemistry",
    r"atomic\s+structure", r"oscillations\s+and\s+waves",
]
LESSON_RX = re.compile("|".join(f"(?:{p})" for p in LESSON_PATTERNS), re.I)
DAY_RX = re.compile(r"(?i)\b(?:day|session|part|lecture|class)\s*[-:#.]?\s*0*(\d{1,3})\b")
SINHALA_DAY_RX = re.compile(r"(?:දින|දිනය|කොටස)\s*[-:#.]?\s*0*(\d{1,3})")
UNIT_RX = re.compile(r"(?i)\bunit\s*[-:#.]?\s*0*(\d{1,3})\b")
LESSON_URL_RX = re.compile(r"https?://[^\s<>\"']+", re.I)


def clean_line(line):
    line = line.replace("\u200b", "").replace("\ufeff", "")
    return re.sub(r"\s+", " ", line.strip(" \t*`_>"))


def lesson_safe_name(value, default):
    """Preserve Sinhala while making a safe Android path component."""
    value = clean_line(str(value))
    value = "".join(ch for ch in value if (unicodedata.category(ch) not in ("So", "Sk") and ch not in ("\u200b", "\ufeff")))
    value = re.sub(r"[\\/<>:\"|?*\x00-\x1f]", " ", value)
    value = re.sub(r"\s+", " ", value).strip(" .-_")
    value = value[:85].strip()
    # Android file systems also limit filename COMPONENTS by bytes, not just characters.
    while len(value.encode("utf-8")) > 175:
        value = value[:-1]
    return value.strip(" .-_") or default


def lesson_from_line(line):
    """Find the actual lesson name, ignoring generic Unit/Full Pack/footer lines."""
    line = clean_line(line)
    if LESSON_URL_RX.search(line) or len(line) > 180:
        return None
    if re.search(r"(?i)\b(?:lesson session|download|react|subscribe|channel|teacher|contact|full lesson pack|lesson store)\b", line):
        # 'Full lesson pack' at end of an explicit topic is allowed below.
        if not LESSON_RX.search(line):
            return None
    # Main subject heading: A/L Biology | <LESSON NAME> (English translation)
    m = SUBJECT_HEADER.search(line) or BARE_SUBJECT_HEADER.search(line)
    if m:
        after = line[m.end():].strip(" |:—–- ")
        after = re.sub(r"(?i)\bunit\s*\d+\s*[:\-]?", "", after).strip()
        after = re.sub(r"(?i)\b(?:full\s*)?lesson\s*pack\b.*$", "", after).strip()
        if after and not re.fullmatch(r"(?i)(?:all\s+lessons?|full\s+syllabus|theory)", after):
            return after
    # Generic lesson headings, with a known lesson name, even without subject.
    k = LESSON_RX.search(line)
    if k:
        # If the line is a simple heading, keep whole heading (including its translated name).
        value = line
        value = re.sub(r"(?i)^.*?\bunit\s*0*\d{1,3}\s*[:|\-]\s*", "", value)
        value = re.sub(r"(?i)\b(?:full\s*)?lesson\s*pack\b.*$", "", value)
        value = re.sub(r"(?i)\b(?:by|teacher|sir)\s*[:\-].*$", "", value)
        return value.strip(" |:—–- ") or k.group()
    # Unit NN: Named Topic, but not 'Full Lesson Pack'.
    u = UNIT_RX.search(line)
    if u:
        after = line[u.end():].strip(" |:—–- ")
        if after and not re.search(r"(?i)\b(?:full|lesson|pack|recordings?)\b", after):
            return after
    return None


def identify_subject(line):
    m = SUBJECT_HEADER.search(line) or BARE_SUBJECT_HEADER.search(line)
    if m:
        return SUBJECTS.get(m.group(1).lower().replace("  ", " "))
    lower = clean_line(line).lower()
    for word, subject in SUBJECTS.items():
        if word in lower and ("විද්‍යාව" in word or "ගණිතය" in word):
            # Sinhala subject-only lines (not arbitrary paragraphs).
            if len(lower) < 38:
                return subject
    return None


def get_youtube_id(raw_url):
    try:
        url = urlparse(raw_url.strip(".,;:!?*])}"))
    except ValueError:
        return None
    host = (url.hostname or "").lower()
    path = url.path.strip("/")
    value = None
    if host in ("youtu.be", "www.youtu.be"):
        value = path.split("/")[0]
    elif host in ("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"):
        if path == "watch":
            value = parse_qs(url.query).get("v", [None])[0]
        elif path.startswith(("shorts/", "live/", "embed/")):
            fields = path.split("/")
            value = fields[1] if len(fields) > 1 else None
    return value if value and re.fullmatch(r"[A-Za-z0-9_-]{11}", value) else None


def parse_messages(message):
    """Segment by lesson/subject headings, and associate each video with its nearest heading.

    Ambiguous items go to Unsorted (rather than silently misclassifying them).
    """
    subject, lesson = DEFAULT_SUBJECT, DEFAULT_LESSON
    pending_day = None
    current_counts = Counter()
    videos = []
    seen = set()
    for raw_line in message.splitlines():
        line = clean_line(raw_line)
        if not line:
            continue
        links = [(m.group(), get_youtube_id(m.group())) for m in LESSON_URL_RX.finditer(line)]
        if not any(vid for _, vid in links):
            next_subject = identify_subject(line)
            if next_subject:
                new_lesson = lesson_from_line(line)
                # New heading means a new block. Do not inherit earlier lesson.
                if next_subject != subject or new_lesson or SUBJECT_HEADER.search(line) or BARE_SUBJECT_HEADER.search(line):
                    subject, lesson = next_subject, (lesson_safe_name(new_lesson, DEFAULT_LESSON) if new_lesson else DEFAULT_LESSON)
                    pending_day = None
            else:
                title = lesson_from_line(line)
                if title:
                    lesson = lesson_safe_name(title, DEFAULT_LESSON)
                    pending_day = None
            day = DAY_RX.search(line) or SINHALA_DAY_RX.search(line)
            if day:
                pending_day = int(day.group(1))
            continue
        for raw_url, video_id in links:
            if not video_id or video_id in seen:
                continue
            seen.add(video_id)
            key = (subject, lesson)
            current_counts[key] += 1
            day_match = DAY_RX.search(line) or SINHALA_DAY_RX.search(line)
            if day_match:
                label = f"Day {int(day_match.group(1)):02d}"
            elif pending_day is not None:
                label = f"Day {pending_day:02d}"
            else:
                label = f"Video {current_counts[key]:02d}"
            videos.append({
                "id": video_id,
                "url": f"https://www.youtube.com/watch?v={video_id}",
                "subject": lesson_safe_name(subject, DEFAULT_SUBJECT),
                "lesson": lesson_safe_name(lesson, DEFAULT_LESSON),
                "label": label,
                "status": "pending",
                "added": datetime.now().isoformat(timespec="seconds"),
            })
            # One label applies to one link unless another is given explicitly.
            pending_day = None
    return videos



if __name__=='__main__':
    root=Path.home()/'storage'/'downloads'/'Malindu All Downloader'
    if not root.parent.exists(): root=Path.home()/'Downloads'/'Malindu All Downloader'
    url=start(root); print('\nMalindu All Downloader\n'+url+'\nKeep this terminal open.',flush=True)
    if shutil.which('termux-open-url'): subprocess.Popen(['termux-open-url',url])
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt: SERVER.shutdown()
