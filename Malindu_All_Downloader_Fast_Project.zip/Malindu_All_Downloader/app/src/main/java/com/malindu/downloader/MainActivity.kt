package com.malindu.downloader

import android.app.Activity
import android.content.Intent
import android.os.*
import android.view.*
import android.webkit.*
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var shared: String? = null
    private var loaded = false
    private var ready = false
    private val connect = object : Runnable {
        override fun run() {
            val url = DownloadService.dashboard
            when {
                url != null && !loaded -> { loaded = true; web.loadUrl(url); status.visibility = View.GONE }
                DownloadService.startupError != null -> { status.text = "Startup failed:\n${DownloadService.startupError}\nClose and reopen the app to retry." }
                !loaded -> handler.postDelayed(this, 500)
            }
        }
    }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xff101321.toInt()) }
        // Keep content clear of Android 15 edge-to-edge system bars.
        box.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom); insets
        }
        status = TextView(this).apply { text="Starting Malindu All Downloader…\nFirst launch may take a little longer."; setTextColor(-1); setPadding(24,40,24,24) }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                val base = DownloadService.dashboard?.let { android.net.Uri.parse(it) }
                return uri.scheme != "http" || uri.host != "127.0.0.1" || uri.port != base?.port
            }
            override fun onPageFinished(view: WebView?, url: String?) { ready = true; deliverShare() }
        }
        box.addView(status); box.addView(web, LinearLayout.LayoutParams(-1,0,1f)); setContentView(box)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        captureShare(intent)
        startForegroundService(Intent(this, DownloadService::class.java))
        handler.post(connect)
    }
    private fun captureShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) shared = intent.getStringExtra(Intent.EXTRA_TEXT)
    }
    private fun deliverShare() { if (ready) shared?.let { web.evaluateJavascript("window.addSharedText(${JSONObject.quote(it)})",null); shared=null } }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); captureShare(intent); deliverShare() }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); web.destroy(); super.onDestroy() }
}
