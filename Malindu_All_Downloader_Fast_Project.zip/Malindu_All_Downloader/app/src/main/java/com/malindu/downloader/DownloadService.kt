package com.malindu.downloader

import android.app.*
import android.content.*
import android.os.*
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.ffmpeg.FFmpeg
import org.json.JSONArray
import java.io.File

class DownloadService : Service() {
    companion object {
        @Volatile var dashboard: String? = null
        @Volatile var startupError: String? = null
        @Volatile var initialized = false
    }
    private var starting = false
    override fun onBind(intent: Intent?) = null
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("downloads", "Downloads", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        startForeground(10, Notification.Builder(this, "downloads").setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("Malindu All Downloader").setContentText("Download engine is running").setContentIntent(open).setOngoing(true).build())
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!starting && !initialized) {
            starting = true; startupError = null
            Thread {
                try {
                    YoutubeDL.getInstance().init(this)
                    FFmpeg.getInstance().init(this)
                    if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                    val root = File(filesDir, "malindu").apply { mkdirs() }
                    dashboard = Python.getInstance().getModule("malindu").callAttr("start", root.absolutePath, this).toString()
                    initialized = true
                } catch (e: Exception) { startupError = e.message ?: e.toString(); starting = false }
            }.start()
        }
        return START_NOT_STICKY
    }
    // Called by the embedded Python worker, never exposed to web pages.
    fun video(url: String, args: String, id: String) {
        val array = JSONArray(args)
        val request = YoutubeDLRequest(url)
        // The wrapper exposes addOption, not addCommands. Preserve the exact
        // yt-dlp argument order, including flags and their values.
        for (i in 0 until array.length()) request.addOption(array.getString(i))
        YoutubeDL.getInstance().execute(request, id) { progress, _, line ->
            Python.getInstance().getModule("malindu").callAttr("native_progress", id, progress, line)
        }
    }
    fun cancel(id: String) { YoutubeDL.getInstance().destroyProcessById(id) }
    fun exportFiles(directory: String) {
        val folder = File(directory)
        val prefs = getSharedPreferences("exports", MODE_PRIVATE)
        folder.walkTopDown().filter { it.isFile && it.extension !in listOf("part", "ytdl", "tmp", "sqlite3", "sqlite3-shm", "sqlite3-wal") }.forEach { file ->
            val key = file.absolutePath + ":" + file.length() + ":" + file.lastModified()
            val previous = prefs.getString(key, null)
            val exists = previous?.let { saved ->
                try { contentResolver.openFileDescriptor(android.net.Uri.parse(saved), "r")?.use { true } ?: false } catch (_: Exception) { false }
            } ?: false
            if (!exists) {
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "application/octet-stream"
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/Malindu All Downloader/${folder.parentFile!!.name}")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Cannot create download file")
                try {
                    contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } } ?: error("Cannot write download")
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                    prefs.edit().putString(key, uri.toString()).apply()
                } catch (e: Exception) { contentResolver.delete(uri, null, null); throw e }
            }
        }
    }
    override fun onTimeout(startId: Int, fgsType: Int) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
}
